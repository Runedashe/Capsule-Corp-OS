import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

// Common 3D printer ports and protocols
const PRINTER_PROTOCOLS = [
  { name: "OctoPrint", port: 80, path: "/api/version", protocol: "octoprint" },
  { name: "OctoPrint HTTPS", port: 443, path: "/api/version", protocol: "octoprint" },
  { name: "Moonraker (Klipper)", port: 7125, path: "/server/info", protocol: "moonraker" },
  { name: "PrusaLink", port: 80, path: "/api/version", protocol: "prusalink" },
  { name: "Repetier", port: 3344, path: "/printer/api/stateUpdate", protocol: "repetier" },
  { name: "Bambu Lab", port: 8883, path: "/", protocol: "bambu" },
];

// Scan a single IP for printer presence
async function probeHost(ip, protocol) {
  const url = `http://${ip}:${protocol.port}${protocol.path}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2000);
  try {
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);
    if (res.ok || res.status === 401 || res.status === 403) {
      let info = {};
      try { info = await res.json(); } catch { /* ignore */ }
      return {
        ip,
        port: protocol.port,
        protocol: protocol.protocol,
        name: info?.server || info?.application || protocol.name,
        version: info?.version || info?.api || "unknown",
        reachable: true,
      };
    }
  } catch {
    clearTimeout(timeout);
  }
  return null;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const { subnet = "192.168.1", range_start = 1, range_end = 50, manual_ip } = body;

    const discovered = [];

    // If a manual IP is given, probe just that one
    if (manual_ip) {
      for (const protocol of PRINTER_PROTOCOLS) {
        const result = await probeHost(manual_ip, protocol);
        if (result) {
          discovered.push({ ...result, id: `${result.ip}:${result.port}` });
          break;
        }
      }
    } else {
      // Scan subnet range concurrently
      const scanTargets = [];
      for (let i = range_start; i <= Math.min(range_end, range_start + 30); i++) {
        for (const protocol of PRINTER_PROTOCOLS.slice(0, 3)) { // limit to top 3 protocols for speed
          scanTargets.push({ ip: `${subnet}.${i}`, protocol });
        }
      }

      const results = await Promise.allSettled(
        scanTargets.map(({ ip, protocol }) => probeHost(ip, protocol))
      );

      const seen = new Set();
      for (const r of results) {
        if (r.status === "fulfilled" && r.value) {
          const key = `${r.value.ip}:${r.value.port}`;
          if (!seen.has(key)) {
            seen.add(key);
            discovered.push({ ...r.value, id: key });
          }
        }
      }
    }

    // Also return well-known cloud/WiFi printers that can be connected by name
    const cloudPrinters = [
      { id: "bambu_cloud", name: "Bambu Lab (Cloud)", protocol: "bambu", reachable: true, ip: "cloud.bambulab.com" },
      { id: "prusa_connect", name: "Prusa Connect (Cloud)", protocol: "prusalink", reachable: true, ip: "connect.prusa3d.com" },
    ];

    return Response.json({
      discovered: [...discovered, ...cloudPrinters],
      scanned_range: manual_ip ? manual_ip : `${subnet}.${range_start}-${range_end}`,
      total_found: discovered.length,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});