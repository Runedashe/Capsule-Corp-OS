import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

async function sendToOctoPrint(ip, port, fileUrl, fileName) {
  // Download file and upload to OctoPrint
  const fileRes = await fetch(fileUrl);
  const fileBlob = await fileRes.blob();

  const form = new FormData();
  form.append("file", fileBlob, fileName || "model.stl");
  form.append("print", "true");

  const uploadRes = await fetch(`http://${ip}:${port}/api/files/local`, {
    method: "POST",
    body: form,
  });

  if (!uploadRes.ok) throw new Error(`OctoPrint upload failed: ${uploadRes.status}`);
  return await uploadRes.json();
}

async function sendToMoonraker(ip, port, fileUrl, fileName) {
  const fileRes = await fetch(fileUrl);
  const fileBlob = await fileRes.blob();

  const form = new FormData();
  form.append("file", fileBlob, fileName || "model.gcode");

  const uploadRes = await fetch(`http://${ip}:${port}/server/files/upload`, {
    method: "POST",
    body: form,
  });

  if (!uploadRes.ok) throw new Error(`Moonraker upload failed: ${uploadRes.status}`);

  // Start print
  await fetch(`http://${ip}:${port}/printer/print/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ filename: fileName || "model.gcode" }),
  });

  return { status: "printing" };
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const { print_job_id, bubble_id, printer_ip, printer_port, printer_protocol, file_url, file_name } = await req.json();

    if (!printer_ip || !file_url) {
      return Response.json({ error: "printer_ip and file_url are required" }, { status: 400 });
    }

    let result = {};
    const port = printer_port || 80;

    if (printer_protocol === "octoprint") {
      result = await sendToOctoPrint(printer_ip, port, file_url, file_name);
    } else if (printer_protocol === "moonraker") {
      result = await sendToMoonraker(printer_ip, 7125, file_url, file_name);
    } else {
      // For unsupported protocols, mark as manual/queued
      result = { status: "queued_manual", message: "File ready — please start print manually on device." };
    }

    // Update print job status in DB
    if (print_job_id) {
      await base44.asServiceRole.entities.PrintJob.update(print_job_id, {
        status: "printing",
        started_at: new Date().toISOString(),
      });
    }

    // Update bubble status
    if (bubble_id) {
      await base44.asServiceRole.entities.Bubble.update(bubble_id, { status: "printing" });
    }

    return Response.json({ success: true, printer_response: result });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});