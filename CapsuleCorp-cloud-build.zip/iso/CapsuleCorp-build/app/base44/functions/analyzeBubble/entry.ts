import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

    const { name, description, object_type, dimensions, file_type } = await req.json();

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert 3D printing engineer. Analyze this object and provide detailed print specifications.

Object: "${name}"
Type: ${object_type || "unknown"}
Description: ${description || "not provided"}
Dimensions: ${dimensions ? `${dimensions.width}mm x ${dimensions.height}mm x ${dimensions.depth}mm` : "unknown"}
File Format: ${file_type || "STL"}

Return a complete material list and print settings for printing this object on a high-grade FDM or resin 3D printer.`,
      response_json_schema: {
        type: "object",
        properties: {
          materials: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                type: { type: "string" },
                amount_grams: { type: "number" },
                color: { type: "string" },
                purpose: { type: "string" }
              }
            }
          },
          print_settings: {
            type: "object",
            properties: {
              layer_height_mm: { type: "number" },
              infill_percent: { type: "number" },
              supports_required: { type: "boolean" },
              estimated_print_hours: { type: "number" },
              recommended_printer_type: { type: "string" },
              notes: { type: "string" }
            }
          },
          volume_cm3: { type: "number" },
          ai_analysis: { type: "string" }
        }
      }
    });

    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});