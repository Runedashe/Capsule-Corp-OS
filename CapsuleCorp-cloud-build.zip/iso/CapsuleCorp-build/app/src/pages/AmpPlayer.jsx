import React, { useState, useRef, useEffect } from "react";
import { Music, Play, Pause, SkipBack, SkipForward, Volume2 } from "lucide-react";

const SAMPLE_TRACKS = [
  { title: "Neon Drive", artist: "Capsule Corp", url: "https://cdn.pixabay.com/audio/2022/10/30/audio_347111d654.mp3" },
  { title: "Ruby Sunset", artist: "CyberRuby", url: "https://cdn.pixabay.com/audio/2022/03/15/audio_8f0d31f3d1.mp3" },
  { title: "Wave Rider", artist: "OS Collective", url: "https://cdn.pixabay.com/audio/2022/05/27/audio_1808fbf07a.mp3" },
];

export default function AmpPlayer() {
  const [current, setCurrent] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [progress, setProgress] = useState(0);
  const audioRef = useRef(null);

  const track = SAMPLE_TRACKS[current];

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume;
  }, [volume]);

  const toggle = () => {
    if (!audioRef.current) return;
    if (playing) { audioRef.current.pause(); setPlaying(false); }
    else { audioRef.current.play(); setPlaying(true); }
  };

  const skip = (dir) => {
    setPlaying(false);
    setCurrent(c => (c + dir + SAMPLE_TRACKS.length) % SAMPLE_TRACKS.length);
    setProgress(0);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 font-mono text-white"
      style={{ background: "linear-gradient(135deg,#1a1a2e,#0f0f1e)" }}>
      <div className="w-full max-w-md bg-black/40 border border-blue-500/30 rounded-2xl p-8"
        style={{ boxShadow: "0 0 30px rgba(0,170,255,0.2)" }}>
        <div className="flex items-center gap-3 mb-6">
          <Music className="w-7 h-7 text-blue-400" />
          <h1 className="text-xl font-bold text-blue-400">AmpPlayer</h1>
        </div>

        <div className="w-40 h-40 mx-auto mb-6 rounded-full bg-gradient-to-br from-blue-600 to-purple-700 flex items-center justify-center"
          style={{ animation: playing ? "spin 8s linear infinite" : "none" }}>
          <Music className="w-16 h-16 text-white/80" />
        </div>

        <h2 className="text-center text-lg font-bold">{track.title}</h2>
        <p className="text-center text-sm text-gray-400 mb-4">{track.artist}</p>

        <input type="range" min="0" max="100" value={progress}
          onChange={e => { setProgress(e.target.value); if (audioRef.current) audioRef.current.currentTime = (e.target.value/100) * (audioRef.current.duration || 0); }}
          className="w-full accent-blue-500 mb-4" />

        <div className="flex items-center justify-center gap-6 mb-4">
          <button onClick={() => skip(-1)} className="text-gray-300 hover:text-white"><SkipBack className="w-6 h-6" /></button>
          <button onClick={toggle}
            className="w-14 h-14 rounded-full bg-blue-600 hover:bg-blue-500 flex items-center justify-center">
            {playing ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
          </button>
          <button onClick={() => skip(1)} className="text-gray-300 hover:text-white"><SkipForward className="w-6 h-6" /></button>
        </div>

        <div className="flex items-center gap-2">
          <Volume2 className="w-4 h-4 text-gray-400" />
          <input type="range" min="0" max="1" step="0.01" value={volume}
            onChange={e => setVolume(parseFloat(e.target.value))} className="w-full accent-blue-500" />
        </div>

        <audio ref={audioRef} src={track.url}
          onTimeUpdate={e => setProgress((e.target.currentTime / (e.target.duration || 1)) * 100)}
          onEnded={() => skip(1)} />
      </div>
    </div>
  );
}