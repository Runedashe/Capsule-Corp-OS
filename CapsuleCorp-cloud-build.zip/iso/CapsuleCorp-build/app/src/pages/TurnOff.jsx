import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Power, RotateCcw, Lock } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function TurnOff() {
  const navigate = useNavigate();
  const [stage, setStage] = useState("confirm"); // confirm | shutting | off

  const shutdown = () => {
    setStage("shutting");
    setTimeout(() => setStage("off"), 2500);
  };

  if (stage === "shutting") {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center font-mono text-white">
        <Power className="w-12 h-12 text-red-500 animate-pulse mb-4" />
        <p className="text-red-400 text-lg">Shutting down CyberRuby OS...</p>
      </div>
    );
  }

  if (stage === "off") {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center font-mono text-white gap-6">
        <p className="text-gray-600 text-sm">System is off.</p>
        <button onClick={() => { base44.auth.logout(); }}
          className="bg-cyan-600 hover:bg-cyan-500 px-6 py-3 rounded-lg flex items-center gap-2">
          <RotateCcw className="w-5 h-5" /> Power On (Log out)
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center font-mono text-white"
      style={{ background: "linear-gradient(135deg,#1a1a2e,#0f0f1e)" }}>
      <div className="bg-black/50 border border-red-500/30 rounded-2xl p-8 max-w-sm text-center">
        <Power className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h1 className="text-xl font-bold mb-2">Turn Off CyberRuby OS</h1>
        <p className="text-sm text-gray-400 mb-6">This will log you out of the system.</p>
        <div className="flex gap-3 justify-center">
          <button onClick={shutdown} className="bg-red-600 hover:bg-red-500 px-5 py-2 rounded-lg flex items-center gap-2">
            <Power className="w-4 h-4" /> Shut Down
          </button>
          <button onClick={() => navigate("/Terminal")} className="bg-gray-700 hover:bg-gray-600 px-5 py-2 rounded-lg flex items-center gap-2">
            <Lock className="w-4 h-4" /> Cancel
          </button>
        </div>
      </div>
    </div>
  );
}