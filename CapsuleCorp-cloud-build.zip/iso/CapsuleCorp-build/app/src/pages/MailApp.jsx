import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Mail, Send, Inbox, Loader2 } from "lucide-react";

export default function MailApp() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [composing, setComposing] = useState(false);
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        const inbox = await base44.entities.Message.filter({ to_user: me.email }, "-created_date", 50);
        setMessages(inbox);
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    })();
  }, []);

  const send = async () => {
    if (!to.trim() || !subject.trim()) return;
    setSending(true);
    try {
      const me = await base44.auth.me();
      await base44.entities.Message.create({
        from_user: me.email, to_user: to.trim(),
        content: `${subject}\n\n${body}`, message_type: "user",
      });
      setComposing(false); setTo(""); setSubject(""); setBody("");
    } catch (e) { console.error(e); }
    finally { setSending(false); }
  };

  return (
    <div className="min-h-screen p-6 font-mono text-white" style={{ background: "linear-gradient(135deg,#1a1a2e,#0f0f1e)" }}>
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Mail className="w-8 h-8 text-yellow-400" />
            <h1 className="text-2xl font-bold text-yellow-400">CyberRuby Mail</h1>
          </div>
          <button onClick={() => setComposing(c => !c)}
            className="bg-yellow-600 hover:bg-yellow-500 px-4 py-2 rounded-lg flex items-center gap-2 text-sm">
            <Send className="w-4 h-4" /> Compose
          </button>
        </div>

        {composing && (
          <div className="mb-6 bg-black/40 border border-yellow-500/30 rounded-lg p-4 space-y-3">
            <input value={to} onChange={e => setTo(e.target.value)} placeholder="To (email)"
              className="w-full bg-black/60 border border-yellow-500/30 rounded px-3 py-2 text-sm outline-none focus:border-yellow-500" />
            <input value={subject} onChange={e => setSubject(e.target.value)} placeholder="Subject"
              className="w-full bg-black/60 border border-yellow-500/30 rounded px-3 py-2 text-sm outline-none focus:border-yellow-500" />
            <textarea value={body} onChange={e => setBody(e.target.value)} placeholder="Message body..." rows={4}
              className="w-full bg-black/60 border border-yellow-500/30 rounded px-3 py-2 text-sm outline-none focus:border-yellow-500" />
            <button onClick={send} disabled={sending}
              className="bg-yellow-600 hover:bg-yellow-500 disabled:opacity-50 px-4 py-2 rounded-lg text-sm flex items-center gap-2">
              {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />} Send
            </button>
          </div>
        )}

        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-yellow-400" /></div>
        ) : messages.length === 0 ? (
          <div className="text-center text-gray-500 py-20">
            <Inbox className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>No messages in your inbox.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {messages.map(m => (
              <div key={m.id} className="bg-black/40 border border-yellow-500/20 rounded-lg p-3 flex items-start gap-3">
                <div className="flex-1">
                  <p className="text-xs text-gray-400">From: {m.from_user}</p>
                  <p className="text-sm text-white mt-1 whitespace-pre-wrap">{m.content}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}