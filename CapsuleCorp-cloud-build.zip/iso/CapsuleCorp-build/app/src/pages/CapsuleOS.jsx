import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Package, Printer, RefreshCw, Loader2, Zap } from "lucide-react";
import CapsuleCard from "@/components/capsule/CapsuleCard";
import NewBubbleModal from "@/components/capsule/NewBubbleModal";
import PrintModal from "@/components/capsule/PrintModal";

export default function CapsuleOS() {
  const [user, setUser] = useState(null);
  const [bubbles, setBubbles] = useState([]);
  const [printJobs, setPrintJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showNewBubble, setShowNewBubble] = useState(false);
  const [printingBubble, setPrintingBubble] = useState(null);
  const [activeTab, setActiveTab] = useState("bubbles");

  const loadData = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      const [bubs, jobs] = await Promise.all([
        base44.entities.Bubble.filter({ owner_email: currentUser.email }, "-created_date"),
        base44.entities.PrintJob.filter({ owner_email: currentUser.email }, "-created_date", 20),
      ]);
      setBubbles(bubs);
      setPrintJobs(jobs);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  const handleToggleCapsule = async (bubble) => {
    const updated = await base44.entities.Bubble.update(bubble.id, {
      is_capsulated: !bubble.is_capsulated,
      status: !bubble.is_capsulated ? "capsulated" : "stored",
    });
    setBubbles(prev => prev.map(b => b.id === bubble.id ? { ...b, ...updated } : b));
  };

  const statusBadge = (status) => {
    const map = {
      queued: "bg-yellow-900/50 text-yellow-400 border-yellow-400/40",
      connecting: "bg-blue-900/50 text-blue-400 border-blue-400/40",
      printing: "bg-green-900/50 text-green-400 border-green-400/40 animate-pulse",
      completed: "bg-cyan-900/50 text-cyan-400 border-cyan-400/40",
      failed: "bg-red-900/50 text-red-400 border-red-400/40",
    };
    return map[status] || "bg-gray-900/50 text-gray-400 border-gray-400/40";
  };

  if (loading) return (
    <div className="flex items-center justify-center h-screen">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="w-12 h-12 text-cyan-400 animate-spin bloom-glow" />
        <p className="text-white font-mono">Loading Capsule OS...</p>
      </div>
    </div>
  );

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto font-mono text-white">
      {/* Header */}
      <div className="mb-6 flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white bloom-glow flex items-center gap-3 mb-1">
            <Zap className="w-8 h-8 text-cyan-400" />
            CAPSULE OS
          </h1>
          <p className="text-cyan-400 text-sm">3D Object Bubble Storage &amp; Wireless Print Management</p>
        </div>
        <div className="flex gap-2">
          <button onClick={loadData}
            className="flex items-center gap-1 text-sm text-gray-400 hover:text-white border border-gray-700 rounded px-2 py-1.5 transition-colors">
            <RefreshCw className="w-4 h-4" />
          </button>
          <button onClick={() => setShowNewBubble(true)}
            className="flex items-center gap-2 bg-cyan-700 hover:bg-cyan-600 text-white rounded px-3 py-1.5 text-sm font-bold transition-colors">
            <Plus className="w-4 h-4" /> New Bubble
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: "BUBBLES STORED", value: bubbles.length, color: "text-cyan-400" },
          { label: "CAPSULATED", value: bubbles.filter(b => b.is_capsulated).length, color: "text-purple-400" },
          { label: "PRINT JOBS", value: printJobs.length, color: "text-green-400" },
        ].map(s => (
          <div key={s.label} className="bg-black/60 border border-cyan-400/30 rounded-lg p-3 text-center">
            <div className={`text-2xl font-bold ${s.color} bloom-glow`}>{s.value}</div>
            <div className="text-xs text-gray-400 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-4 border-b border-cyan-400/20 pb-0">
        {[
          { key: "bubbles", label: "BUBBLE STORAGE", icon: Package },
          { key: "jobs", label: "PRINT QUEUE", icon: Printer },
        ].map(t => (
          <button key={t.key} onClick={() => setActiveTab(t.key)}
            className={`flex items-center gap-2 px-4 py-2 text-sm border-b-2 transition-colors -mb-px ${
              activeTab === t.key
                ? "border-cyan-400 text-cyan-400"
                : "border-transparent text-gray-500 hover:text-gray-300"
            }`}>
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>

      {/* Bubbles Tab */}
      {activeTab === "bubbles" && (
        <div>
          {bubbles.length === 0 ? (
            <div className="text-center py-16 text-gray-500">
              <Package className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>No bubbles stored yet.</p>
              <button onClick={() => setShowNewBubble(true)}
                className="mt-3 text-cyan-400 hover:underline text-sm">Scan your first object →</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {bubbles.map(b => (
                <CapsuleCard key={b.id} bubble={b}
                  onPrint={setPrintingBubble}
                  onToggleCapsule={handleToggleCapsule} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Print Jobs Tab */}
      {activeTab === "jobs" && (
        <div className="space-y-3">
          {printJobs.length === 0 ? (
            <div className="text-center py-16 text-gray-500">
              <Printer className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>No print jobs yet.</p>
            </div>
          ) : (
            printJobs.map(job => (
              <div key={job.id} className="bg-black/70 border border-cyan-400/30 rounded-lg p-4 flex items-center justify-between">
                <div>
                  <div className="text-white font-bold text-sm">{job.bubble_name}</div>
                  <div className="text-gray-400 text-xs mt-0.5">
                    {job.printer_name || "Unknown Printer"}
                    {job.printer_ip && ` · ${job.printer_ip}`}
                  </div>
                  {job.estimated_hours > 0 && (
                    <div className="text-gray-500 text-xs mt-0.5">Est. {job.estimated_hours}h</div>
                  )}
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span className={`text-xs px-2 py-0.5 rounded border uppercase ${statusBadge(job.status)}`}>
                    {job.status}
                  </span>
                  {job.progress_percent > 0 && (
                    <div className="w-20 bg-gray-800 rounded-full h-1.5">
                      <div className="bg-cyan-400 h-1.5 rounded-full transition-all"
                        style={{ width: `${job.progress_percent}%` }} />
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Modals */}
      {showNewBubble && (
        <NewBubbleModal user={user} onClose={() => setShowNewBubble(false)} onCreated={loadData} />
      )}
      {printingBubble && (
        <PrintModal bubble={printingBubble} user={user}
          onClose={() => setPrintingBubble(null)}
          onJobCreated={loadData} />
      )}
    </div>
  );
}