import React, { useState } from "react";
import { Cpu, Gauge, Zap, Activity, Volume2, Palette, Usb } from "lucide-react";

// Local planning only. Vehicle communication belongs to Car Diagnostics;
// this page does not implement vehicle-specific calibration or ECU programming.
const TOTAL_POINTS = 100;
const STORAGE_KEY = "capsulecorp.vehicle-plan.v1";
const GEAR_SOUNDS = [
  { id: "turbo_spool", name: "Turbo Spool", desc: "Rising high-frequency whistle as exhaust spins the turbine." },
  { id: "compressor_surge", name: "Compressor Surge", desc: "Chopping 'stututu' on throttle lift-off." },
  { id: "bov_whoosh", name: "Blow-Off Valve Whoosh", desc: "Sharp 'psshhh' snap when shifting gears." },
  { id: "supercharger_whine", name: "Supercharger Whine", desc: "Continuous mechanical wail rising with RPM." },
  { id: "eturbo_whir", name: "E-Turbo / Futuristic Whir", desc: "Electronic jet/spaceship-like whine." },
];
const ACCENT_COLORS = ["Violet", "Indigo", "Blue", "Green", "Yellow", "Orange", "Red", "Chartreuse"];

function readPlan() {
  const defaults = {
    car: "VW Golf GTI MK6",
    points: { acceleration: 40, speed: 35, handling: 25 },
    gearSound: "turbo_spool",
    accentColor: "Blue",
  };
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (!stored || typeof stored !== "object") return defaults;
    const values = ["acceleration", "speed", "handling"].map(key => stored.points?.[key]);
    const validPoints = values.every(value => Number.isInteger(value) && value >= 0 && value <= TOTAL_POINTS)
      && values.reduce((sum, value) => sum + value, 0) === TOTAL_POINTS;
    return {
      car: typeof stored.car === "string" ? stored.car : defaults.car,
      points: validPoints ? stored.points : defaults.points,
      gearSound: GEAR_SOUNDS.some(sound => sound.id === stored.gearSound) ? stored.gearSound : defaults.gearSound,
      accentColor: ACCENT_COLORS.includes(stored.accentColor) ? stored.accentColor : defaults.accentColor,
    };
  } catch {
    return defaults;
  }
}

export default function TRGTuner() {
  const [plan, setPlan] = useState(readPlan);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState("");
  const { car, points, gearSound, accentColor } = plan;
  const used = points.acceleration + points.speed + points.handling;

  const updatePlan = changes => {
    setPlan(previous => ({ ...previous, ...changes }));
    setSaved(false);
    setSaveError("");
  };

  const adjust = (key, delta) => {
    setPlan(previous => {
      const next = Math.max(0, Math.min(TOTAL_POINTS, previous.points[key] + delta));
      const newUsed = Object.entries(previous.points).reduce((sum, [name, value]) => sum + (name === key ? next : value), 0);
      if (newUsed > TOTAL_POINTS) return previous;
      return { ...previous, points: { ...previous.points, [key]: next } };
    });
    setSaved(false);
    setSaveError("");
  };

  const savePlan = () => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...plan, savedAt: new Date().toISOString() }));
      setSaved(true);
      setSaveError("");
    } catch {
      setSaved(false);
      setSaveError("Your browser could not save this plan. Check that local storage is available.");
    }
  };

  const bars = [
    { key: "acceleration", label: "Acceleration", icon: Zap, color: "#FF4444" },
    { key: "speed", label: "Speed", icon: Gauge, color: "#00FFFF" },
    { key: "handling", label: "Handling", icon: Activity, color: "#00FF88" },
  ];

  return (
    <div className="min-h-screen p-6 max-w-3xl mx-auto font-mono text-white"
      style={{ background: "radial-gradient(circle at 50% 30%, #1a0a0a 0%, #000 100%)" }}>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <img src="/capsule-corp-logo.png" alt="TRG" className="w-12 h-12 object-contain" />
          <div>
            <h1 className="text-2xl font-bold bloom-glow" style={{ color: "#FF4444" }}>TRG TUNER</h1>
            <p className="text-gray-400 text-xs">Vehicle customization planner</p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-gray-600 text-gray-400 text-xs">
          Local plan
        </div>
      </div>

      <div className="bg-black/60 border border-red-400/30 rounded-lg p-6 text-center mb-4">
        <Cpu className="w-12 h-12 mx-auto mb-3 text-red-400" />
        <p className="text-gray-300 mb-2">Real USB → OBD-II diagnostics</p>
        <p className="text-gray-400 text-xs mb-4">Open Car Diagnostics to select a supported USB serial adapter and read live vehicle data. A connection is confirmed only after the adapter responds.</p>
        <a href="/car-diagnostics"
          className="inline-flex items-center gap-2 bg-red-700 hover:bg-red-600 text-white px-6 py-2 rounded-lg font-bold transition-colors">
          <Usb className="w-4 h-4" /> Open Car Diagnostics
        </a>
        <p className="text-gray-400 text-xs mt-4">ECU programming is not implemented. Preferences below are saved only in this browser and do not change your vehicle.</p>
      </div>

      <div className="bg-black/60 border border-cyan-400/30 rounded-lg p-5 mb-4">
        <label htmlFor="vehicle-plan-name" className="block text-cyan-400 font-bold mb-2">VEHICLE</label>
        <input id="vehicle-plan-name" value={car} onChange={event => updatePlan({ car: event.target.value })}
          maxLength={120} className="w-full bg-gray-900 border border-gray-700 rounded p-2 text-sm text-white" />
      </div>

      <div className="bg-black/60 border border-cyan-400/30 rounded-lg p-5 mb-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-cyan-400 font-bold">PERFORMANCE PRIORITIES</h2>
          <span className={`text-sm ${used === TOTAL_POINTS ? "text-green-400" : "text-yellow-400"}`}>
            {used} / {TOTAL_POINTS} points
          </span>
        </div>
        <p className="text-gray-400 text-xs mb-4">Allocate your planning priorities. These points are not measured performance or ECU calibration values.</p>
        <div className="space-y-4">
          {bars.map(b => (
            <div key={b.key}>
              <div className="flex justify-between text-sm mb-1">
                <span className="flex items-center gap-2"><b.icon className="w-4 h-4" style={{ color: b.color }} /> {b.label}</span>
                <span style={{ color: b.color }}>{points[b.key]}</span>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => adjust(b.key, -5)} aria-label={`Decrease ${b.label} priority`} className="w-7 h-7 rounded bg-gray-800 hover:bg-gray-700 text-white">−</button>
                <div className="flex-1 h-3 bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all" style={{ width: `${points[b.key]}%`, background: b.color }} />
                </div>
                <button onClick={() => adjust(b.key, 5)} aria-label={`Increase ${b.label} priority`} className="w-7 h-7 rounded bg-gray-800 hover:bg-gray-700 text-white">+</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-black/60 border border-yellow-400/30 rounded-lg p-5 mb-4">
        <h2 className="text-yellow-400 font-bold mb-3 flex items-center gap-2"><Volume2 className="w-4 h-4" /> SOUND PREFERENCE</h2>
        <p className="text-gray-400 text-xs mb-3">Record a sound idea for your plan. Selecting an option does not produce audio or alter vehicle hardware.</p>
        <div className="space-y-2">
          {GEAR_SOUNDS.map(s => (
            <button key={s.id} onClick={() => updatePlan({ gearSound: s.id })} aria-pressed={gearSound === s.id}
              className={`w-full text-left p-2 rounded border transition-colors ${
                gearSound === s.id ? "border-yellow-400 bg-yellow-900/30" : "border-gray-700 hover:border-yellow-400/50"
              }`}>
              <div className="text-sm text-white">{s.name}</div>
              <div className="text-xs text-gray-400">{s.desc}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-black/60 border border-purple-400/30 rounded-lg p-5 mb-4">
        <h2 className="text-purple-400 font-bold mb-3 flex items-center gap-2"><Palette className="w-4 h-4" /> ACCENT COLOR IDEA</h2>
        <p className="text-gray-400 text-xs mb-3">A visual preference for your saved plan.</p>
        <div className="flex flex-wrap gap-2 mb-3">
          {ACCENT_COLORS.map(c => (
            <button key={c} onClick={() => updatePlan({ accentColor: c })} aria-pressed={accentColor === c}
              className={`px-3 py-1 rounded text-xs border transition-all ${
                accentColor === c ? "scale-110 border-white" : "border-transparent opacity-70"
              }`}
              style={{ background: c.toLowerCase(), color: ["yellow", "chartreuse", "orange"].includes(c.toLowerCase()) ? "#000" : "#fff" }}>
              {c}
            </button>
          ))}
        </div>
      </div>

      <button onClick={savePlan} disabled={used !== TOTAL_POINTS}
        className="w-full bg-green-700 hover:bg-green-600 disabled:opacity-40 text-white py-2 rounded-lg font-bold transition-colors">
        {saved ? "✓ Plan Saved on This Device" : "Save Plan on This Device"}
      </button>
      <p role="status" className="text-gray-400 text-xs mt-2 text-center">
        {saved ? "This browser's local storage contains your plan. Clearing browser data removes it." : "Allocate all 100 priority points to save your plan."}
      </p>
      {saveError && <p role="alert" className="text-red-400 text-xs mt-2 text-center">{saveError}</p>}
    </div>
  );
}
