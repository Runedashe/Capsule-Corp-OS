import { useEffect, useRef, useState } from 'react';
import { Usb, Loader2, Cpu, RefreshCw } from 'lucide-react';
import { Elm327, SENSORS } from '@/lib/elm327';

export default function CarDiagnostics() {
  const [baudRate, setBaudRate] = useState(38400);
  const [connecting, setConnecting] = useState(false);
  const [connected, setConnected] = useState(false);
  const [identity, setIdentity] = useState('');
  const [error, setError] = useState('');
  const [samples, setSamples] = useState(null);
  const [readAt, setReadAt] = useState(null);
  const [reading, setReading] = useState(false);
  const client = useRef(null);
  const generation = useRef(0);
  const busy = useRef(false);
  const available = typeof navigator !== 'undefined' && 'serial' in navigator && window.isSecureContext;

  useEffect(() => () => {
    generation.current += 1;
    void client.current?.close();
    client.current = null;
  }, []);

  const disconnect = async () => {
    generation.current += 1;
    const current = client.current;
    client.current = null;
    setConnected(false);
    setConnecting(false);
    setReading(false);
    setSamples(null);
    setReadAt(null);
    await current?.close();
  };

  const connect = async () => {
    const session = ++generation.current;
    setConnecting(true);
    setError('');
    setSamples(null);
    setReadAt(null);
    let adapter;
    try {
      const port = await navigator.serial.requestPort();
      if (session !== generation.current) return;
      adapter = new Elm327(port, failure => {
        if (session !== generation.current) return;
        setConnected(false);
        setSamples(null);
        setReadAt(null);
        setError(failure.message || 'USB adapter disconnected');
      });
      client.current = adapter;
      const detected = await adapter.open(baudRate);
      if (session !== generation.current) { await adapter.close(); return; }
      setIdentity(detected);
      setConnected(true);
    } catch (failure) {
      await adapter?.close();
      if (session === generation.current) {
        client.current = null;
        setError(failure.name === 'NotFoundError' ? 'No adapter selected.' : failure.message || 'Could not open adapter');
      }
    } finally {
      if (session === generation.current) setConnecting(false);
    }
  };

  const refresh = async () => {
    if (!client.current || busy.current || !connected) return;
    const session = generation.current;
    busy.current = true;
    setReading(true);
    try {
      const values = await client.current.sample();
      if (session !== generation.current) return;
      setSamples(values);
      setReadAt(new Date());
      setError(Object.values(values).some(v => v.value !== null) ? '' : 'No supported sensor returned a current reading.');
    } catch (failure) {
      if (session === generation.current) {
        setSamples(null);
        setReadAt(null);
        setConnected(false);
        setError(failure.message || 'Vehicle read failed');
      }
    } finally {
      busy.current = false;
      if (session === generation.current) setReading(false);
    }
  };

  return (
    <div className="min-h-screen p-6 max-w-3xl mx-auto font-mono text-white" style={{ background: 'radial-gradient(circle at 50% 30%, #0a1a0a 0%, #000 100%)' }}>
      <div className="flex items-center gap-3 mb-6">
        <Cpu className="w-10 h-10 text-green-400" />
        <div><h1 className="text-2xl font-bold text-green-400">OBD-II DIAGNOSTICS</h1><p className="text-gray-400 text-xs">USB ELM327 · Read-only vehicle measurements</p></div>
      </div>
      <div className="border border-green-400/30 bg-black/60 rounded-lg p-5 mb-5">
        <p role="status" className="flex items-center gap-2 text-green-300"><Usb className="w-4 h-4" />{connecting ? 'Checking adapter and vehicle…' : connected ? 'Adapter open · vehicle handshake verified' : 'Disconnected'}</p>
        <p className="text-sm text-gray-300 mt-3">Connect an ELM327-compatible USB serial adapter to the vehicle. Park safely and turn the ignition on before reading.</p>
        {!available && <p role="alert" className="mt-3 text-yellow-300">Web Serial is unavailable. Open this app in the ISO’s Chromium browser or a compatible browser on HTTPS/localhost.</p>}
        <div className="flex flex-wrap items-center gap-3 mt-4">
          <label className="text-sm">Adapter baud rate <select value={baudRate} disabled={connected || connecting} onChange={e => setBaudRate(Number(e.target.value))} className="ml-2 p-2 bg-gray-900 rounded border border-gray-600">{[9600, 38400, 115200].map(rate => <option key={rate} value={rate}>{rate}</option>)}</select></label>
          {!connected && !connecting && <button disabled={!available} onClick={connect} className="px-4 py-2 rounded bg-green-700 disabled:opacity-40">Select USB adapter</button>}
          {(connected || connecting) && <button onClick={disconnect} className="px-4 py-2 rounded bg-gray-700">Disconnect</button>}
        </div>
        <p className="text-xs text-gray-400 mt-3">Use the baud rate specified by your adapter. J2534 and proprietary USB cables are not supported by this ELM327 driver.</p>
        {connected && <p className="text-xs text-gray-400 mt-2">Adapter identification: {identity}</p>}
        {error && <p role="alert" className="mt-3 text-amber-300 text-sm">{error}</p>}
      </div>
      <div className="border border-cyan-400/30 rounded-lg p-5">
        <div className="flex items-center justify-between gap-3 mb-4"><h2 className="font-bold text-cyan-400">VEHICLE READINGS</h2><button disabled={!connected || reading} onClick={refresh} className="flex items-center gap-2 px-3 py-2 rounded bg-cyan-900 disabled:opacity-40">{reading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}{reading ? 'Reading…' : 'Read sensors'}</button></div>
        <div className="grid grid-cols-2 gap-3">{SENSORS.map(sensor => {
          const sample = samples?.[sensor.key];
          return <div key={sensor.key} className="border border-cyan-400/20 rounded p-4"><div className="text-xs text-gray-400">{sensor.label}</div><div className="text-2xl text-cyan-300 mt-2">{sample?.value == null ? '—' : Number(sample.value.toFixed(1))}<span className="ml-1 text-xs">{sensor.unit}</span></div><p className="text-xs text-gray-500 mt-1">{sample?.status || 'Not read'}</p></div>;
        })}</div>
        <p className="text-xs text-gray-400 mt-4">{readAt ? `Last read: ${readAt.toLocaleTimeString()}. Press Read sensors for a fresh measurement.` : 'Measurements appear only after valid responses from the vehicle.'}</p>
      </div>
      <p className="text-xs text-gray-400 mt-5">This driver reads standard supported sensors. Fault-code decoding, code clearing, ECU programming and manufacturer-specific tuning are not implemented. No vehicle readings are generated locally.</p>
    </div>
  );
}
