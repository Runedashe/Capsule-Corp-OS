import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Folder, File as FileIcon, Upload, Loader2, Trash2 } from "lucide-react";

export default function UserDirectory() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const me = await base44.auth.me();
      const list = await base44.entities.File.filter({ owner_email: me.email }, "-created_date", 100);
      setFiles(list);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const me = await base44.auth.me();
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      await base44.entities.File.create({
        filename: file.name, file_url, file_size: file.size,
        file_type: file.type, owner_email: me.email,
      });
      await load();
    } catch (e) { console.error(e); }
    finally { setUploading(false); }
  };

  const remove = async (id) => {
    await base44.entities.File.delete(id);
    setFiles(files.filter(f => f.id !== id));
  };

  const fmtSize = (b) => b ? (b < 1024 ? `${b} B` : b < 1048576 ? `${(b/1024).toFixed(1)} KB` : `${(b/1048576).toFixed(1)} MB`) : "—";

  return (
    <div className="min-h-screen p-6 font-mono text-white" style={{ background: "linear-gradient(135deg,#1a1a2e,#0f0f1e)" }}>
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Folder className="w-8 h-8 text-purple-400" />
            <h1 className="text-2xl font-bold text-purple-400">User Directory</h1>
          </div>
          <label className="bg-purple-600 hover:bg-purple-500 px-4 py-2 rounded-lg flex items-center gap-2 text-sm cursor-pointer">
            {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            Upload
            <input type="file" className="hidden" onChange={handleUpload} disabled={uploading} />
          </label>
        </div>

        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
        ) : files.length === 0 ? (
          <div className="text-center text-gray-500 py-20">
            <Folder className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>Your directory is empty. Upload a file to get started.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {files.map(f => (
              <div key={f.id} className="bg-black/40 border border-purple-500/20 rounded-lg p-3 flex items-center gap-3">
                <FileIcon className="w-5 h-5 text-purple-400 shrink-0" />
                <div className="flex-1 min-w-0">
                  <a href={f.file_url} target="_blank" rel="noreferrer" className="text-sm text-white hover:text-purple-300 truncate block">{f.filename}</a>
                  <p className="text-xs text-gray-500">{fmtSize(f.file_size)} · {f.file_type || "file"}</p>
                </div>
                <button onClick={() => remove(f.id)} className="text-red-400 hover:text-red-300"><Trash2 className="w-4 h-4" /></button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}