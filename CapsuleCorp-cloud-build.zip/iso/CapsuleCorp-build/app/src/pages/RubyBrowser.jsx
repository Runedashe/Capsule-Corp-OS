import React, { useState } from "react";
import { Globe, ArrowLeft, ArrowRight, RotateCw, Lock } from "lucide-react";

export default function RubyBrowser() {
  const [url, setUrl] = useState("https://en.wikipedia.org/wiki/Capsule_Corp");
  const [input, setInput] = useState(url);
  const [history, setHistory] = useState([url]);
  const [idx, setIdx] = useState(0);
  const [error, setError] = useState(false);

  const navigate = (target) => {
    let full = target.trim();
    if (!/^https?:\/\//.test(full)) {
      if (full.includes(".") && !full.includes(" ")) full = "https://" + full;
      else full = "https://duckduckgo.com/?q=" + encodeURIComponent(full);
    }
    setUrl(full); setInput(full);
    const h = [...history.slice(0, idx + 1), full];
    setHistory(h); setIdx(h.length - 1); setError(false);
  };

  const back = () => { if (idx > 0) { setIdx(idx - 1); setUrl(history[idx - 1]); setInput(history[idx - 1]); } };
  const forward = () => { if (idx < history.length - 1) { setIdx(idx + 1); setUrl(history[idx + 1]); setInput(history[idx + 1]); } };
  const reload = () => { setUrl(u => u + (u.includes("?") ? "&" : "?") + "_=" + Date.now()); };

  return (
    <div className="min-h-screen flex flex-col font-mono" style={{ background: "#0f0f1e" }}>
      <div className="flex items-center gap-2 p-3 bg-black/60 border-b border-orange-500/30">
        <button onClick={back} disabled={idx === 0} className="text-gray-400 hover:text-white disabled:opacity-30"><ArrowLeft className="w-5 h-5" /></button>
        <button onClick={forward} disabled={idx === history.length - 1} className="text-gray-400 hover:text-white disabled:opacity-30"><ArrowRight className="w-5 h-5" /></button>
        <button onClick={reload} className="text-gray-400 hover:text-white"><RotateCw className="w-5 h-5" /></button>
        <Lock className="w-4 h-4 text-green-400" />
        <input value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && navigate(input)}
          className="flex-1 bg-black/60 border border-orange-500/30 rounded-full px-4 py-1.5 text-sm text-white outline-none focus:border-orange-500" />
        <Globe className="w-5 h-5 text-orange-400" />
      </div>
      <div className="flex-1 bg-white">
        <iframe src={url} title="RUBY Browser" className="w-full h-full min-h-[70vh]"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
          onError={() => setError(true)} />
        {error && (
          <div className="p-10 text-center text-gray-500">
            <p>This site can't be embedded. <a href={url} target="_blank" rel="noreferrer" className="text-orange-400 underline">Open in new tab</a></p>
          </div>
        )}
      </div>
    </div>
  );
}