import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { X, Send, Loader2 } from "lucide-react";
import ReactMarkdown from "react-markdown";

// Red Ribbon — Super Agent AI chat panel. Lives inside Orbit Messenger as a
// special AI contact. Writes code to program anything in CyberRuby OS.
const RED_RIBBON_LOGO = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6870dea75e7cf7b0574e0e6f/bcbde081c_CapsuleCorpLogo.png";

export default function RedRibbonChat({ isOpen, onClose }) {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (!isOpen) return;
    (async () => {
      try {
        const convos = await base44.agents.listConversations({ agent_name: "RedRibbon" });
        let convo = convos.find(c => c.metadata?.name === "Red Ribbon");
        if (!convo) {
          convo = await base44.agents.createConversation({
            agent_name: "RedRibbon",
            metadata: { name: "Red Ribbon", description: "Super Agent AI" },
          });
        }
        setConversation(convo);
        setMessages(convo.messages || []);
      } catch (e) {
        console.error("Red Ribbon init error:", e);
      }
    })();
  }, [isOpen]);

  useEffect(() => {
    if (!conversation?.id) return;
    const unsub = base44.agents.subscribeToConversation(conversation.id, (data) => {
      setMessages(data.messages || []);
    });
    return unsub;
  }, [conversation?.id]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const send = async () => {
    if (!input.trim() || !conversation || loading) return;
    const text = input.trim();
    setInput("");
    setLoading(true);
    try {
      await base44.agents.addMessage(conversation, { role: "user", content: text });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60">
      <div className="bg-gray-950 border-2 border-red-500 rounded-xl w-full max-w-2xl h-[80vh] flex flex-col font-mono"
        style={{ boxShadow: "0 0 40px rgba(255,68,68,0.3)" }}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-red-500/30">
          <div className="flex items-center gap-3">
            <img src={RED_RIBBON_LOGO} alt="Red Ribbon" className="w-10 h-10 object-contain rounded-full" />
            <div>
              <h2 className="text-red-400 font-bold bloom-glow">RED RIBBON</h2>
              <p className="text-gray-500 text-xs">Super Agent AI · Code Writer</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.length === 0 && (
            <div className="text-center text-gray-500 mt-10">
              <img src={RED_RIBBON_LOGO} alt="RR" className="w-16 h-16 mx-auto mb-3 rounded-full opacity-60" />
              <p className="text-sm">Red Ribbon is online. Ask me to write code to program anything.</p>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                m.role === "user" ? "bg-cyan-900/50 text-cyan-100" : "bg-red-900/30 text-gray-100 border border-red-500/30"
              }`}>
                {m.role === "user" ? m.content : <ReactMarkdown>{m.content || ""}</ReactMarkdown>}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="bg-red-900/30 border border-red-500/30 rounded-lg px-3 py-2">
                <Loader2 className="w-4 h-4 animate-spin text-red-400" />
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="p-4 border-t border-red-500/30 flex gap-2">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && send()}
            placeholder="Ask Red Ribbon to write code..."
            className="flex-1 bg-black border border-red-500/40 text-white rounded px-3 py-2 text-sm focus:border-red-500 outline-none"
          />
          <button onClick={send} disabled={loading || !input.trim()}
            className="bg-red-700 hover:bg-red-600 disabled:opacity-40 text-white px-4 rounded transition-colors">
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}