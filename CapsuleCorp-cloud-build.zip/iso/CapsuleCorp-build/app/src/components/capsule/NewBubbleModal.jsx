import React, { useState } from "react";
import { X, Upload, Loader2, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { analyzeBubble } from "@/functions/analyzeBubble";

const OBJECT_TYPES = ["Vehicle", "Shelter/Home", "Tool", "Food Container", "Electronics", "Furniture", "Medical Device", "Weapon/Defense", "Custom"];
const CAPSULE_COLORS = ["cyan", "red", "yellow", "green", "purple"];

export default function NewBubbleModal({ user, onClose, onCreated }) {
  const [form, setForm] = useState({
    name: "", description: "", object_type: "", capsule_color: "cyan",
    dimensions: { width: "", height: "", depth: "" },
    file_type: "STL",
  });
  const [fileUrl, setFileUrl] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [saving, setSaving] = useState(false);

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFileUrl(file_url);
      const ext = file.name.split(".").pop().toUpperCase();
      setForm(f => ({ ...f, file_type: ext }));
    } finally {
      setUploading(false);
    }
  };

  const handleAnalyze = async () => {
    setAnalyzing(true);
    try {
      const res = await analyzeBubble({
        name: form.name,
        description: form.description,
        object_type: form.object_type,
        dimensions: {
          width: parseFloat(form.dimensions.width) || 0,
          height: parseFloat(form.dimensions.height) || 0,
          depth: parseFloat(form.dimensions.depth) || 0,
        },
        file_type: form.file_type,
      });
      setAnalysisResult(res.data);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const bubbleData = {
        name: form.name,
        description: form.description,
        object_type: form.object_type,
        capsule_color: form.capsule_color,
        file_url: fileUrl,
        file_type: form.file_type,
        dimensions: {
          width: parseFloat(form.dimensions.width) || 0,
          height: parseFloat(form.dimensions.height) || 0,
          depth: parseFloat(form.dimensions.depth) || 0,
        },
        owner_email: user.email,
        status: "stored",
        is_capsulated: false,
        ...(analysisResult || {}),
      };
      await base44.entities.Bubble.create(bubbleData);
      onCreated();
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className="bg-gray-950 border-2 border-cyan-400 rounded-xl w-full max-w-lg font-mono max-h-[90vh] overflow-y-auto"
        style={{ boxShadow: "0 0 40px rgba(0,255,255,0.2)" }}>
        <div className="flex items-center justify-between p-4 border-b border-cyan-400/30">
          <h2 className="text-cyan-400 font-bold text-lg bloom-glow">NEW BUBBLE SCAN</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-4 space-y-4">
          <div>
            <label className="text-xs text-gray-400 block mb-1">OBJECT NAME *</label>
            <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              className="w-full bg-black border border-cyan-400/40 text-white rounded px-3 py-2 text-sm focus:border-cyan-400 outline-none" />
          </div>

          <div>
            <label className="text-xs text-gray-400 block mb-1">OBJECT TYPE</label>
            <select value={form.object_type} onChange={e => setForm(f => ({ ...f, object_type: e.target.value }))}
              className="w-full bg-black border border-cyan-400/40 text-white rounded px-3 py-2 text-sm focus:border-cyan-400 outline-none">
              <option value="">Select type...</option>
              {OBJECT_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>

          <div>
            <label className="text-xs text-gray-400 block mb-1">DESCRIPTION</label>
            <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              rows={2} className="w-full bg-black border border-cyan-400/40 text-white rounded px-3 py-2 text-sm focus:border-cyan-400 outline-none resize-none" />
          </div>

          <div>
            <label className="text-xs text-gray-400 block mb-1">DIMENSIONS (mm)</label>
            <div className="grid grid-cols-3 gap-2">
              {["width", "height", "depth"].map(d => (
                <input key={d} type="number" placeholder={d.charAt(0).toUpperCase() + d.slice(1)}
                  value={form.dimensions[d]}
                  onChange={e => setForm(f => ({ ...f, dimensions: { ...f.dimensions, [d]: e.target.value } }))}
                  className="bg-black border border-cyan-400/40 text-white rounded px-2 py-2 text-sm text-center focus:border-cyan-400 outline-none" />
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-gray-400 block mb-1">CAPSULE COLOR</label>
            <div className="flex gap-2">
              {CAPSULE_COLORS.map(c => (
                <button key={c} onClick={() => setForm(f => ({ ...f, capsule_color: c }))}
                  className={`w-8 h-8 rounded-full border-2 transition-all ${form.capsule_color === c ? "scale-125" : "opacity-60"}`}
                  style={{ background: c === "cyan" ? "#00FFFF" : c === "red" ? "#FF4444" : c === "yellow" ? "#FFFF00" : c === "green" ? "#00FF88" : "#CC00FF",
                    borderColor: form.capsule_color === c ? "white" : "transparent" }} />
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs text-gray-400 block mb-1">UPLOAD 3D FILE (STL, OBJ, GLB)</label>
            <label className="flex items-center gap-2 cursor-pointer border border-dashed border-cyan-400/40 rounded px-3 py-3 hover:border-cyan-400 transition-colors">
              {uploading ? <Loader2 className="w-4 h-4 animate-spin text-cyan-400" /> : <Upload className="w-4 h-4 text-cyan-400" />}
              <span className="text-sm text-gray-300">{fileUrl ? "File uploaded ✓" : "Click to upload"}</span>
              <input type="file" accept=".stl,.obj,.glb,.gcode" className="hidden" onChange={handleFileUpload} />
            </label>
          </div>

          {/* AI Analyze button */}
          {form.name && (
            <button onClick={handleAnalyze} disabled={analyzing}
              className="w-full flex items-center justify-center gap-2 bg-indigo-900/60 hover:bg-indigo-800/80 border border-indigo-400/50 text-indigo-300 rounded px-3 py-2 text-sm transition-colors">
              {analyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {analyzing ? "Analyzing with AI..." : "AI Analyze Materials & Settings"}
            </button>
          )}

          {/* Analysis Result */}
          {analysisResult && (
            <div className="bg-black/60 border border-green-400/30 rounded p-3 text-xs space-y-1">
              <div className="text-green-400 font-bold mb-2">AI ANALYSIS COMPLETE</div>
              {analysisResult.materials?.slice(0, 3).map((m, i) => (
                <div key={i} className="flex justify-between text-gray-300">
                  <span>{m.name}</span><span className="text-yellow-400">{m.amount_grams}g</span>
                </div>
              ))}
              {analysisResult.print_settings && (
                <div className="text-gray-400 pt-1">
                  Est. {analysisResult.print_settings.estimated_print_hours}h print |
                  {analysisResult.print_settings.infill_percent}% infill
                </div>
              )}
            </div>
          )}

          <button onClick={handleSave} disabled={!form.name || saving}
            className="w-full bg-cyan-700 hover:bg-cyan-600 disabled:opacity-40 text-white rounded py-2 text-sm font-bold transition-colors">
            {saving ? "Saving to Bubble Storage..." : "SAVE BUBBLE"}
          </button>
        </div>
      </div>
    </div>
  );
}