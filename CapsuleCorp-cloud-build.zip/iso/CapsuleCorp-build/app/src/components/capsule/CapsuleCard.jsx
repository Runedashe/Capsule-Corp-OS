import React, { useState } from "react";
import { Package, Printer, Zap, ChevronDown, ChevronUp } from "lucide-react";

const CAPSULE_COLORS = {
  cyan: { outer: "#00FFFF", inner: "#005f5f", glow: "0 0 20px #00FFFF" },
  red: { outer: "#FF4444", inner: "#5f0000", glow: "0 0 20px #FF4444" },
  yellow: { outer: "#FFFF00", inner: "#5f5f00", glow: "0 0 20px #FFFF00" },
  green: { outer: "#00FF88", inner: "#005f30", glow: "0 0 20px #00FF88" },
  purple: { outer: "#CC00FF", inner: "#3f005f", glow: "0 0 20px #CC00FF" },
};

function CapsuleIcon({ color = "cyan", size = 64, isOpen }) {
  const c = CAPSULE_COLORS[color] || CAPSULE_COLORS.cyan;
  return (
    <div style={{ width: size, height: size * 1.6, position: "relative", cursor: "pointer" }}>
      {/* Top half (button) */}
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0,
        height: "45%",
        background: `radial-gradient(circle at 40% 35%, #fff4, ${c.outer}88, ${c.inner})`,
        border: `2px solid ${c.outer}`,
        borderRadius: "50% 50% 0 0",
        boxShadow: c.glow,
        transition: "transform 0.4s ease",
        transform: isOpen ? "translateY(-14px) rotate(-8deg)" : "none",
      }}>
        {/* Button on top */}
        <div style={{
          position: "absolute", top: "20%", left: "50%", transform: "translate(-50%, -50%)",
          width: size * 0.22, height: size * 0.22,
          background: c.outer,
          borderRadius: "50%",
          boxShadow: `0 0 8px ${c.outer}`,
        }} />
      </div>
      {/* Bottom half */}
      <div style={{
        position: "absolute", bottom: 0, left: 0, right: 0,
        height: "55%",
        background: `radial-gradient(circle at 40% 60%, #fff2, ${c.outer}44, #000)`,
        border: `2px solid ${c.outer}88`,
        borderRadius: "0 0 50% 50%",
        boxShadow: `inset 0 0 12px ${c.inner}`,
        transition: "transform 0.4s ease",
        transform: isOpen ? "translateY(8px)" : "none",
      }} />
      {/* Seam line */}
      {!isOpen && (
        <div style={{
          position: "absolute", top: "44%", left: 0, right: 0,
          height: "3px",
          background: `linear-gradient(90deg, transparent, ${c.outer}, transparent)`,
          boxShadow: `0 0 6px ${c.outer}`,
        }} />
      )}
    </div>
  );
}

export default function CapsuleCard({ bubble, onPrint, onToggleCapsule }) {
  const [expanded, setExpanded] = useState(false);
  const [capsuleOpen, setCapsuleOpen] = useState(false);

  const handleCapsuleClick = () => {
    setCapsuleOpen(true);
    setTimeout(() => setCapsuleOpen(false), 5000);
    onToggleCapsule && onToggleCapsule(bubble);
  };

  const statusColor = {
    stored: "text-cyan-400",
    printing: "text-yellow-400 animate-pulse",
    printed: "text-green-400",
    capsulated: "text-purple-400",
  }[bubble.status] || "text-gray-400";

  return (
    <div className="bg-black/80 border border-cyan-400/50 rounded-lg p-4 font-mono hover:border-cyan-400 transition-all"
      style={{ boxShadow: "0 0 10px rgba(0,255,255,0.1)" }}>
      <div className="flex items-start gap-4">
        {/* Capsule visual */}
        <div className="flex-shrink-0 flex flex-col items-center gap-2">
          <div onClick={bubble.is_capsulated ? handleCapsuleClick : undefined}
            className={bubble.is_capsulated ? "cursor-pointer" : "opacity-40"}>
            <CapsuleIcon color={bubble.capsule_color || "cyan"} size={48} isOpen={capsuleOpen} />
          </div>
          {bubble.is_capsulated && (
            <span className="text-xs text-purple-400 text-center">Tap to open</span>
          )}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-white font-bold truncate">{bubble.name}</h3>
            <span className={`text-xs uppercase ${statusColor}`}>{bubble.status}</span>
          </div>
          {bubble.object_type && (
            <div className="text-xs text-cyan-400 mt-0.5">{bubble.object_type}</div>
          )}
          {bubble.dimensions && (
            <div className="text-xs text-gray-400 mt-1">
              {bubble.dimensions.width}×{bubble.dimensions.height}×{bubble.dimensions.depth} mm
            </div>
          )}

          {/* Materials preview */}
          {bubble.materials?.length > 0 && (
            <div className="mt-2">
              <button onClick={() => setExpanded(!expanded)}
                className="text-xs text-cyan-300 flex items-center gap-1 hover:text-white transition-colors">
                {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                {bubble.materials.length} material{bubble.materials.length !== 1 ? "s" : ""}
              </button>
              {expanded && (
                <div className="mt-2 space-y-1">
                  {bubble.materials.map((m, i) => (
                    <div key={i} className="text-xs flex justify-between text-gray-300">
                      <span>{m.name} ({m.type})</span>
                      <span className="text-yellow-400">{m.amount_grams}g</span>
                    </div>
                  ))}
                  {bubble.print_settings && (
                    <div className="mt-2 pt-2 border-t border-cyan-400/20 text-xs text-gray-400 space-y-0.5">
                      <div>Layer: {bubble.print_settings.layer_height_mm}mm | Infill: {bubble.print_settings.infill_percent}%</div>
                      <div>Est. time: {bubble.print_settings.estimated_print_hours}h</div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2 mt-3">
            <button onClick={() => onPrint(bubble)}
              className="flex items-center gap-1 text-xs bg-green-900/50 hover:bg-green-700/60 text-green-400 border border-green-400/40 rounded px-2 py-1 transition-colors">
              <Printer className="w-3 h-3" /> Print
            </button>
            <button onClick={() => onToggleCapsule(bubble)}
              className={`flex items-center gap-1 text-xs border rounded px-2 py-1 transition-colors ${
                bubble.is_capsulated
                  ? "bg-purple-900/50 hover:bg-purple-700/60 text-purple-400 border-purple-400/40"
                  : "bg-cyan-900/50 hover:bg-cyan-700/60 text-cyan-400 border-cyan-400/40"
              }`}>
              <Zap className="w-3 h-3" />
              {bubble.is_capsulated ? "De-capsulate" : "Capsulate"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}