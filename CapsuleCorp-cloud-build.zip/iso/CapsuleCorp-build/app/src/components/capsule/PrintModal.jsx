import React, { useState } from "react";
import { X, Search, Loader2, Printer, Wifi, CheckCircle2 } from "lucide-react";
import { discoverPrinters } from "@/functions/discoverPrinters";
import { sendPrintJob } from "@/functions/sendPrintJob";
import { base44 } from "@/api/base44Client";

export default function PrintModal({ bubble, user, onClose, onJobCreated }) {
  const [scanning, setScanning] = useState(false);
  const [printers, setPrinters] = useState([]);
  const [selectedPrinter, setSelectedPrinter] = useState(null);
  const [manualIp, setManualIp] = useState("");
  const [subnet, setSubnet] = useState("192.168.1");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleScan = async () => {
    setScanning(true);
    setPrinters([]);
    try {
      const res = await discoverPrinters({ subnet, range_start: 1, range_end: 40 });
      setPrinters(res.data?.discovered || []);
    } finally {
      setScanning(false);
    }
  };

  const handleManualAdd = async () => {
    if (!manualIp) return;
    setScanning(true);
    try {
      const res = await discoverPrinters({ manual_ip: manualIp });
      const found = res.data?.discovered || [];
      if (found.length > 0) {
        setPrinters(prev => [...prev, ...found.filter(p => !prev.find(x => x.id === p.id))]);
      } else {
        // Add as manual entry anyway
        setPrinters(prev => [...prev, {
          id: manualIp, ip: manualIp, name: `Manual: ${manualIp}`,
          protocol: "manual", reachable: true,
        }]);
      }
    } finally {
      setScanning(false);
    }
  };

  const handleSendJob = async () => {
    if (!selectedPrinter) return;
    setSending(true);
    try {
      // Create PrintJob record
      const job = await base44.entities.PrintJob.create({
        bubble_id: bubble.id,
        bubble_name: bubble.name,
        printer_id: selectedPrinter.id,
        printer_name: selectedPrinter.name,
        printer_ip: selectedPrinter.ip,
        printer_protocol: selectedPrinter.protocol,
        status: "queued",
        estimated_hours: bubble.print_settings?.estimated_print_hours || 0,
        owner_email: user.email,
      });

      // Send to printer if file available
      if (bubble.file_url) {
        await sendPrintJob({
          print_job_id: job.id,
          bubble_id: bubble.id,
          printer_ip: selectedPrinter.ip,
          printer_port: selectedPrinter.port || 80,
          printer_protocol: selectedPrinter.protocol,
          file_url: bubble.file_url,
          file_name: `${bubble.name}.${bubble.file_type?.toLowerCase() || "stl"}`,
        });
      }

      setSent(true);
      setTimeout(() => { onJobCreated && onJobCreated(); onClose(); }, 2000);
    } finally {
      setSending(false);
    }
  };

  if (sent) return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center">
      <div className="bg-gray-950 border-2 border-green-400 rounded-xl p-8 text-center font-mono"
        style={{ boxShadow: "0 0 40px rgba(0,255,0,0.3)" }}>
        <CheckCircle2 className="w-16 h-16 text-green-400 mx-auto mb-4 bloom-glow" />
        <div className="text-green-400 text-xl font-bold bloom-glow">PRINT JOB DISPATCHED</div>
        <div className="text-gray-400 text-sm mt-2">Sending to {selectedPrinter?.name}...</div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className="bg-gray-950 border-2 border-cyan-400 rounded-xl w-full max-w-lg font-mono max-h-[90vh] overflow-y-auto"
        style={{ boxShadow: "0 0 40px rgba(0,255,255,0.2)" }}>
        <div className="flex items-center justify-between p-4 border-b border-cyan-400/30">
          <div>
            <h2 className="text-cyan-400 font-bold text-lg bloom-glow">PRINT: {bubble.name}</h2>
            <p className="text-gray-400 text-xs mt-0.5">Locate a wireless 3D printer on your network</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-4 space-y-4">
          {/* Network scan */}
          <div>
            <label className="text-xs text-gray-400 block mb-1">LOCAL SUBNET</label>
            <div className="flex gap-2">
              <input value={subnet} onChange={e => setSubnet(e.target.value)}
                placeholder="192.168.1"
                className="flex-1 bg-black border border-cyan-400/40 text-white rounded px-3 py-2 text-sm focus:border-cyan-400 outline-none" />
              <button onClick={handleScan} disabled={scanning}
                className="flex items-center gap-2 bg-cyan-900/60 hover:bg-cyan-800 border border-cyan-400/50 text-cyan-300 rounded px-3 py-2 text-sm transition-colors">
                {scanning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                Scan
              </button>
            </div>
          </div>

          {/* Manual IP */}
          <div>
            <label className="text-xs text-gray-400 block mb-1">OR ADD PRINTER BY IP</label>
            <div className="flex gap-2">
              <input value={manualIp} onChange={e => setManualIp(e.target.value)}
                placeholder="e.g. 192.168.1.42"
                className="flex-1 bg-black border border-cyan-400/40 text-white rounded px-3 py-2 text-sm focus:border-cyan-400 outline-none" />
              <button onClick={handleManualAdd} disabled={!manualIp || scanning}
                className="bg-indigo-900/60 hover:bg-indigo-800 border border-indigo-400/50 text-indigo-300 rounded px-3 py-2 text-sm transition-colors">
                Add
              </button>
            </div>
          </div>

          {/* Printer list */}
          {printers.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs text-gray-400">{printers.length} PRINTER{printers.length !== 1 ? "S" : ""} FOUND</div>
              {printers.map(p => (
                <button key={p.id} onClick={() => setSelectedPrinter(p)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-all text-left ${
                    selectedPrinter?.id === p.id
                      ? "border-cyan-400 bg-cyan-900/30"
                      : "border-gray-700 bg-black/40 hover:border-cyan-400/50"
                  }`}>
                  <Wifi className={`w-5 h-5 flex-shrink-0 ${p.reachable ? "text-green-400" : "text-gray-500"}`} />
                  <div className="min-w-0">
                    <div className="text-white text-sm font-bold truncate">{p.name}</div>
                    <div className="text-gray-400 text-xs">{p.ip} · {p.protocol}</div>
                  </div>
                  {selectedPrinter?.id === p.id && (
                    <CheckCircle2 className="w-4 h-4 text-cyan-400 ml-auto flex-shrink-0" />
                  )}
                </button>
              ))}
            </div>
          )}

          {scanning && (
            <div className="flex items-center gap-2 text-cyan-400 text-sm">
              <Loader2 className="w-4 h-4 animate-spin" /> Scanning network for 3D printers...
            </div>
          )}

          {/* Print button */}
          <button onClick={handleSendJob} disabled={!selectedPrinter || sending}
            className="w-full flex items-center justify-center gap-2 bg-green-800 hover:bg-green-700 disabled:opacity-40 text-white rounded py-2.5 text-sm font-bold transition-colors mt-2">
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
            {sending ? "Dispatching Print Job..." : "SEND TO PRINTER"}
          </button>
        </div>
      </div>
    </div>
  );
}