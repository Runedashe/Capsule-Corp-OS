import React, { useEffect, useState } from "react";

// Fullscreen boot/loading screen shown during OS initialization.
// Uses a CSS-rendered CyberRuby splash (swap the <img> src for your CyberRuby.png
// once uploaded to storage) stretched to fill the entire screen.
export default function BootScreen({ attempts = 0 }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(p => Math.min(p + Math.random() * 12, 100));
    }, 180);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden"
      style={{ background: "radial-gradient(circle at 50% 40%, #1e1b4b 0%, #0a0a0a 100%)" }}>
      {/* Fullscreen splash image — stretched to cover the whole screen */}
      <img
        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6870dea75e7cf7b0574e0e6f/bcbde081c_CapsuleCorpLogo.png"
        alt="CyberRuby OS"
        className="absolute inset-0 w-full h-full object-contain opacity-20"
      />

      <div className="relative z-10 flex flex-col items-center gap-6 px-6">
        <h1 className="text-5xl md:text-7xl font-bold text-white font-mono bloom-glow tracking-wider"
          style={{ textShadow: "0 0 20px #00FFFF, 0 0 40px #00FFFF" }}>
          CyberRuby OS
        </h1>
        <p className="text-cyan-400 font-mono text-sm tracking-[0.4em] uppercase">Fast Boot · Capsule Corp</p>

        <div className="w-72 md:w-96 mt-4">
          <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-cyan-400 rounded-full transition-all duration-200"
              style={{ width: `${progress}%`, boxShadow: "0 0 10px #00FFFF" }} />
          </div>
          <div className="flex justify-between text-xs text-gray-400 font-mono mt-2">
            <span>{progress < 100 ? "Loading system..." : "Ready"}</span>
            <span>{Math.floor(progress)}%</span>
          </div>
        </div>

        {attempts > 0 && (
          <p className="text-yellow-400 font-mono text-xs">Connection attempt {attempts + 1} of 5...</p>
        )}
      </div>
    </div>
  );
}