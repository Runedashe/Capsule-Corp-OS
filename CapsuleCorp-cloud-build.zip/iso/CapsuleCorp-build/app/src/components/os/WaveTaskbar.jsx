import React, { useState, useEffect, useRef } from "react";
import { Minimize2 } from "lucide-react";

// Auto-hiding taskbar pinned to the TOP of the screen. It slides down when the
// cursor reaches the top edge and hides when it leaves. Background is a live
// animated gold wave on silver; minimized tabs live here to be restored.
export default function WaveTaskbar({ minimizedTabs = [], onRestoreTab }) {
  const [visible, setVisible] = useState(false);
  const hideTimer = useRef(null);

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (e.clientY <= 4) {
        setVisible(true);
        if (hideTimer.current) clearTimeout(hideTimer.current);
      } else if (e.clientY > 60) {
        if (hideTimer.current) clearTimeout(hideTimer.current);
        hideTimer.current = setTimeout(() => setVisible(false), 400);
      }
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      if (hideTimer.current) clearTimeout(hideTimer.current);
    };
  }, []);

  return (
    <>
      {/* Animated wave background — always rendered so it keeps flowing */}
      <div
        className="fixed top-0 left-0 right-0 z-40 transition-transform duration-300 pointer-events-none"
        style={{
          height: 48,
          transform: visible ? "translateY(0)" : "translateY(-100%)",
        }}
      >
        <div className="relative w-full h-full overflow-hidden"
          style={{ background: "linear-gradient(180deg, #c0c0c0 0%, #e8e8e8 50%, #a8a8a8 100%)" }}>
          {/* Gold waves */}
          <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none" viewBox="0 0 1200 48">
            <defs>
              <linearGradient id="goldWave" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FFD700" stopOpacity="0.9" />
                <stop offset="50%" stopColor="#FFC125" stopOpacity="0.6" />
                <stop offset="100%" stopColor="#DAA520" stopOpacity="0.4" />
              </linearGradient>
            </defs>
            {[0, 1, 2].map(i => (
              <path key={i}
                className="wave-path"
                style={{ animation: `waveFlow ${4 + i}s linear infinite` }}
                fill="url(#goldWave)"
                d="M0,24 Q150,8 300,24 T600,24 T900,24 T1200,24 L1200,48 L0,48 Z"
              />
            ))}
          </svg>
        </div>
      </div>

      {/* Interactive taskbar content (pointer events on) */}
      <div
        className="fixed top-0 left-0 right-0 z-50 transition-transform duration-300"
        style={{ transform: visible ? "translateY(0)" : "translateY(-100%)" }}
      >
        <div className="flex items-center gap-2 h-12 px-4">
          {minimizedTabs.length === 0 ? (
            <span className="text-gray-700 font-mono text-xs italic">No minimized tabs</span>
          ) : (
            minimizedTabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => onRestoreTab && onRestoreTab(tab)}
                className="flex items-center gap-2 bg-black/30 hover:bg-black/50 text-white font-mono text-xs px-3 py-1.5 rounded-md border border-yellow-500/40 transition-colors"
                style={{ boxShadow: "0 0 6px rgba(255,215,0,0.3)" }}
              >
                <Minimize2 className="w-3 h-3" />
                {tab.name}
              </button>
            ))
          )}
        </div>
      </div>

      <style>{`
        @keyframes waveFlow {
          0% { transform: translateX(0); }
          100% { transform: translateX(-300px); }
        }
      `}</style>
    </>
  );
}