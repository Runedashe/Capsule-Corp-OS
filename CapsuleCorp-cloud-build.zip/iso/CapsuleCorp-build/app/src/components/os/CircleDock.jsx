import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Terminal, Cpu, Car, Mail, Folder, Music, Power, Globe, Lock } from "lucide-react";

// Circular dock inspired by the GTA V radio-station wheel. Toggle with F12.
// Frost-white transparent ring; center shows the Capsule Corp (cc.png) logo.
// Installed marketplace apps appear here and launch in their own tabs.
const DEFAULT_APPS = [
  { id: "terminal", name: "Terminal", icon: Terminal, color: "#00FFFF", route: "/Terminal" },
  { id: "capsule", name: "Capsule OS", icon: Cpu, color: "#00FF88", route: "/capsule-os" },
  { id: "trg", name: "TRG Tuner", icon: Car, color: "#FF4444", route: "/trg-tuner" },
  { id: "diag", name: "Car Diagnostics", icon: Car, color: "#FFAA00", route: "/car-diagnostics" },
  { id: "mail", name: "Mail", icon: Mail, color: "#FFD700", route: "/mail" },
  { id: "files", name: "User Directory", icon: Folder, color: "#CC00FF", route: "/user-directory" },
  { id: "amp", name: "AmpPlayer", icon: Music, color: "#00AAFF", route: "/amp-player" },
  { id: "ruby", name: "RUBY Browser", icon: Globe, color: "#FF6600", route: "/ruby-browser" },
  { id: "turnoff", name: "Turn Off", icon: Power, color: "#FF0000", route: "/turn-off" },
];

export default function CircleDock({ installedApps = [], onLaunchApp }) {
  const [open, setOpen] = useState(false);
  const [hovered, setHovered] = useState(null);
  const containerRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "F12") {
        e.preventDefault();
        setOpen(prev => !prev);
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  const allApps = [...DEFAULT_APPS, ...installedApps];
  const radius = 130;
  const count = allApps.length;

  return (
    <>
      {/* F12 hint when closed */}
      {!open && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 text-white/40 font-mono text-xs pointer-events-none">
          Press F12 for Circle Dock
        </div>
      )}

      {/* Backdrop */}
      {open && (
        <div
          className="fixed inset-0 z-40 flex items-center justify-center"
          style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(2px)" }}
          onClick={() => setOpen(false)}
        >
          <div ref={containerRef} className="relative" onClick={e => e.stopPropagation()}>
            {/* Frost-white transparent ring */}
            <div
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full"
              style={{
                width: radius * 2 + 80,
                height: radius * 2 + 80,
                background: "rgba(240, 248, 255, 0.12)",
                border: "2px solid rgba(240, 248, 255, 0.4)",
                boxShadow: "0 0 30px rgba(240,248,255,0.25), inset 0 0 20px rgba(240,248,255,0.1)",
                backdropFilter: "blur(8px)",
              }}
            />

            {/* Center logo (cc.png placeholder) */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6870dea75e7cf7b0574e0e6f/bcbde081c_CapsuleCorpLogo.png"
                alt="Capsule Corp"
                className="w-16 h-16 object-contain opacity-80"
              />
            </div>

            {/* App icons arranged in a circle */}
            {allApps.map((app, i) => {
              const angle = (i / count) * 2 * Math.PI - Math.PI / 2;
              const x = Math.cos(angle) * radius;
              const y = Math.sin(angle) * radius;
              const Icon = app.icon;
              const isHovered = hovered === app.id;
              return (
                <button
                  key={app.id}
                  onMouseEnter={() => setHovered(app.id)}
                  onMouseLeave={() => setHovered(null)}
                  onClick={() => {
                    if (onLaunchApp) onLaunchApp(app);
                    navigate(app.route);
                    setOpen(false);
                  }}
                  className="absolute top-1/2 left-1/2 flex flex-col items-center justify-center rounded-full transition-all duration-200"
                  style={{
                    width: isHovered ? 60 : 48,
                    height: isHovered ? 60 : 48,
                    transform: `translate(calc(-50% + ${x}px), calc(-50% + ${y}px))`,
                    background: isHovered ? `${app.color}33` : "rgba(255,255,255,0.08)",
                    border: `1px solid ${app.color}80`,
                    boxShadow: isHovered ? `0 0 16px ${app.color}` : "none",
                  }}
                  title={app.name}
                >
                  <Icon className="w-5 h-5" style={{ color: app.color }} />
                </button>
              );
            })}

            {/* Hovered label */}
            {hovered && (
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 text-white font-mono text-sm font-bold whitespace-nowrap"
                style={{ transform: "translate(-50%, 90px)", textShadow: "0 0 8px currentColor" }}>
                {allApps.find(a => a.id === hovered)?.name}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}