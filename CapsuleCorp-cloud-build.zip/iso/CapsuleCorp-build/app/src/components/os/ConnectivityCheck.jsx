import React, { useState, useEffect, useRef } from "react";
import { Wifi, Usb, Bluetooth, CheckCircle2, XCircle, Loader2 } from "lucide-react";

// Runs a connectivity check for USB and Bluetooth devices before/after login.
// Uses the Web USB / Web Bluetooth APIs where available; falls back to a
// simulated probe so the UX is consistent in browsers without them.
export default function ConnectivityCheck({ stage = "pre-login" }) {
  const [usbStatus, setUsbStatus] = useState("checking");
  const [btStatus, setBtStatus] = useState("checking");
  const [devices, setDevices] = useState([]);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; };
  }, []);

  const probe = async () => {
    setUsbStatus("checking");
    setBtStatus("checking");
    setDevices([]);

    // USB
    try {
      if ("usb" in navigator) {
        // WebUSB available — list already-paired devices
        const paired = await navigator.usb.getDevices().catch(() => []);
        if (mounted.current) {
          setUsbStatus(paired.length > 0 ? "connected" : "available");
          setDevices(prev => [
            ...prev,
            ...paired.map(d => ({ type: "USB", name: `${d.productName || "USB Device"} (${d.manufacturerName || "Unknown"})` })),
          ]);
        }
      } else {
        if (mounted.current) setUsbStatus("unavailable");
      }
    } catch {
      if (mounted.current) setUsbStatus("error");
    }

    // Bluetooth
    try {
      if ("bluetooth" in navigator) {
        // Don't request — just check availability
        if (navigator.bluetooth.getAvailability) {
          const avail = await navigator.bluetooth.getAvailability();
          if (mounted.current) setBtStatus(avail ? "available" : "unavailable");
        } else {
          if (mounted.current) setBtStatus("available");
        }
      } else {
        if (mounted.current) setBtStatus("unavailable");
      }
    } catch {
      if (mounted.current) setBtStatus("error");
    }
  };

  useEffect(() => { probe(); }, [stage]);

  const statusIcon = (status) => {
    if (status === "checking") return <Loader2 className="w-4 h-4 animate-spin text-yellow-400" />;
    if (status === "connected" || status === "available") return <CheckCircle2 className="w-4 h-4 text-green-400" />;
    return <XCircle className="w-4 h-4 text-red-400" />;
  };

  const statusLabel = (status) => ({
    checking: "Scanning...",
    connected: "Connected",
    available: "Ready",
    unavailable: "Not supported",
    error: "Error",
  }[status] || status);

  return (
    <div className="bg-black/70 border border-cyan-400/30 rounded-lg p-3 font-mono text-xs">
      <div className="text-cyan-400 mb-2 uppercase tracking-wider">
        {stage === "pre-login" ? "Pre-Login" : "Post-Login"} Device Connectivity
      </div>
      <div className="flex gap-4">
        <div className="flex items-center gap-2">
          <Usb className="w-4 h-4 text-cyan-400" />
          USB {statusIcon(usbStatus)} <span className="text-gray-400">{statusLabel(usbStatus)}</span>
        </div>
        <div className="flex items-center gap-2">
          <Bluetooth className="w-4 h-4 text-cyan-400" />
          BT {statusIcon(btStatus)} <span className="text-gray-400">{statusLabel(btStatus)}</span>
        </div>
      </div>
      {devices.length > 0 && (
        <div className="mt-2 pt-2 border-t border-cyan-400/20 space-y-1">
          {devices.map((d, i) => (
            <div key={i} className="text-green-400">→ {d.name}</div>
          ))}
        </div>
      )}
    </div>
  );
}