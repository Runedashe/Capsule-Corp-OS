export default function AuthLayout({ icon: Icon, title, subtitle, footer, brandLogo = false, beforeForm, children }) {
  return (
    <div className={`min-h-screen flex items-center justify-center px-4 ${brandLogo ? "dark bg-black py-8 text-foreground" : "bg-background"}`}>
      <div className="w-full max-w-md">
        <div className={`text-center ${brandLogo ? "mb-8" : "mb-10"}`}>
          {brandLogo ? (
            <img
              src="/capsule-corp-logo.png"
              alt="Capsule Corp"
              width="500"
              height="500"
              className="mx-auto mb-4 h-40 w-40 object-contain sm:h-48 sm:w-48"
              fetchPriority="high"
            />
          ) : (
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary mb-4">
              <Icon className="w-7 h-7 text-primary-foreground" aria-hidden="true" />
            </div>
          )}
          <h1 className="text-3xl font-bold tracking-tight text-foreground">{title}</h1>
          {subtitle && <p className="text-muted-foreground mt-2">{subtitle}</p>}
        </div>
        {beforeForm}
        <div className="bg-card rounded-2xl shadow-sm border border-border p-8">
          {children}
        </div>
        {footer && (
          <p className="text-center text-sm text-muted-foreground mt-6">{footer}</p>
        )}
      </div>
    </div>
  );
}
