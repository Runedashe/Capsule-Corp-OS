import { useCallback, useEffect, useRef, useState } from "react";
import { Globe, Loader2, RefreshCw, Settings2, Wifi, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";

// The ISO serves the app and its native network controls on this loopback origin.
const hasNativeNetwork = () => window.location.origin === "http://127.0.0.1:8080";
const unknownStatus = { online: null, connected: null, connection: "", interface: "" };

export default function LoginConnectivity() {
  const [nativeNetwork] = useState(hasNativeNetwork);
  const [status, setStatus] = useState(unknownStatus);
  const [checking, setChecking] = useState(true);
  const [opening, setOpening] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const mounted = useRef(false);
  const currentRequest = useRef(null);

  const checkConnection = useCallback(async () => {
    if (!nativeNetwork) {
      // navigator.onLine indicates a network link, not verified internet access.
      setStatus({ ...unknownStatus, connected: navigator.onLine });
      setChecking(false);
      return;
    }

    if (currentRequest.current) return;
    const controller = new AbortController();
    currentRequest.current = controller;
    const timeout = window.setTimeout(() => controller.abort(), 8000);
    setChecking(true);
    try {
      const response = await fetch("/api/local/network/status", {
        signal: controller.signal,
        cache: "no-store",
        credentials: "same-origin",
      });
      if (!response.ok) throw new Error("Network status unavailable");
      const result = await response.json();
      if (typeof result.connected !== "boolean" ||
          (typeof result.online !== "boolean" && result.online !== null)) {
        throw new Error("Network status unavailable");
      }
      if (mounted.current && currentRequest.current === controller) {
        setStatus({
          online: result.online,
          connected: result.connected,
          connection: typeof result.connection === "string" ? result.connection : "",
          interface: typeof result.interface === "string" ? result.interface : "",
        });
      }
    } catch {
      if (mounted.current && currentRequest.current === controller) setStatus(unknownStatus);
    } finally {
      window.clearTimeout(timeout);
      if (currentRequest.current === controller) {
        currentRequest.current = null;
        if (mounted.current) setChecking(false);
      }
    }
  }, [nativeNetwork]);

  useEffect(() => {
    mounted.current = true;
    checkConnection();
    const interval = window.setInterval(checkConnection, 15000);
    window.addEventListener("online", checkConnection);
    window.addEventListener("offline", checkConnection);
    window.addEventListener("focus", checkConnection);
    return () => {
      mounted.current = false;
      window.clearInterval(interval);
      currentRequest.current?.abort();
      currentRequest.current = null;
      window.removeEventListener("online", checkConnection);
      window.removeEventListener("offline", checkConnection);
      window.removeEventListener("focus", checkConnection);
    };
  }, [checkConnection]);

  const openNetworkSetup = async () => {
    if (!nativeNetwork || opening) return;
    setOpening(true);
    setNotice("");
    setError("");
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch("/api/local/network/setup", {
        method: "POST",
        credentials: "same-origin",
        signal: controller.signal,
      });
      if (!response.ok) throw new Error("Could not open network settings");
      if (mounted.current) {
        setNotice("Network settings opened. Choose Activate a connection to join Wi-Fi or Ethernet, then return here.");
      }
    } catch {
      if (mounted.current) {
        setError("Network settings could not open. Use the desktop network menu, then select Refresh here.");
      }
    } finally {
      window.clearTimeout(timeout);
      if (mounted.current) setOpening(false);
    }
  };

  let statusText = "Network status unavailable";
  let StatusIcon = Globe;
  if (checking && status.connected === null) {
    statusText = "Checking connection…";
    StatusIcon = Loader2;
  } else if (status.online === true) {
    statusText = "Internet available";
    StatusIcon = Wifi;
  } else if (status.connected === false) {
    statusText = nativeNetwork ? "No network connection" : "Browser reports offline";
    StatusIcon = WifiOff;
  } else if (status.connected === true) {
    statusText = nativeNetwork
      ? (status.online === false ? "Connected · no internet detected" : "Connected · internet status unknown")
      : "Browser reports a network connection";
    StatusIcon = Wifi;
  }

  return (
    <section className="mb-5 rounded-2xl border border-border bg-card p-5" aria-labelledby="login-connectivity-title">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h2 id="login-connectivity-title" className="text-sm font-semibold">Internet connectivity</h2>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={checkConnection}
          disabled={checking}
          aria-label="Refresh network status"
          className="h-8 px-2 text-xs"
        >
          <RefreshCw className={`mr-1.5 h-3.5 w-3.5 ${checking ? "animate-spin" : ""}`} aria-hidden="true" />
          Refresh
        </Button>
      </div>
      <div role="status" aria-live="polite" className="space-y-1">
        <p className="flex items-center gap-2 text-sm">
          <StatusIcon className={`h-4 w-4 shrink-0 ${StatusIcon === Loader2 ? "animate-spin" : ""} ${status.online === true ? "text-emerald-400" : "text-muted-foreground"}`} aria-hidden="true" />
          {statusText}
        </p>
        {nativeNetwork && status.connected && (status.connection || status.interface) && (
          <p className="break-words pl-6 text-xs text-muted-foreground">
            {[status.connection, status.interface].filter(Boolean).join(" · ")}
          </p>
        )}
      </div>
      <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
        {nativeNetwork
          ? "Connect before signing in. Wi-Fi and Ethernet settings are available without an account."
          : "Internet access is required to sign in. Use your device’s Wi-Fi or Ethernet settings; browser status does not verify internet access."}
      </p>
      {nativeNetwork && (
        <Button type="button" variant="outline" size="sm" onClick={openNetworkSetup} disabled={opening} className="mt-3 w-full">
          {opening ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden="true" /> : <Settings2 className="mr-2 h-4 w-4" aria-hidden="true" />}
          {opening ? "Opening settings…" : "Set up Wi-Fi / Ethernet"}
        </Button>
      )}
      {notice && <p role="status" className="mt-3 text-xs leading-relaxed text-muted-foreground">{notice}</p>}
      {error && <p role="alert" className="mt-3 text-xs leading-relaxed text-red-400">{error}</p>}
    </section>
  );
}
