import React, { useState, useEffect, useRef } from "react";
import { X } from "lucide-react";
import { base44 } from "@/api/base44Client";

const POUCH_LOGO = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6870dea75e7cf7b0574e0e6f/9c66856a1_PouchLogo.png";

const getBalanceColor = (balance) => {
  if (balance >= 1_000_000_000) return "text-red-600 bloom-glow";
  if (balance >= 1_000_000) return "text-cyan-400 bloom-glow";
  if (balance >= 100_000) return "text-white bloom-glow";
  return "text-yellow-400";
};

export default function PouchPopup({ isOpen, onClose, user }) {
  const [shdPrice, setShdPrice] = useState(null);
  const [priceLoading, setPriceLoading] = useState(false);
  const intervalRef = useRef(null);

  const fetchPrice = async () => {
    setPriceLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: "Get the current price of Shard (SHD) cryptocurrency in USD. Return just the current price as a number.",
        add_context_from_internet: true,
        response_json_schema: { type: "object", properties: { price: { type: "number" } } }
      });
      setShdPrice(result.price || null);
    } catch {
      setShdPrice(null);
    } finally {
      setPriceLoading(false);
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    fetchPrice();
    intervalRef.current = setInterval(fetchPrice, 60000);
    return () => clearInterval(intervalRef.current);
  }, [isOpen]);

  if (!isOpen) return null;

  const usdValue = shdPrice && user?.shard_balance
    ? (user.shard_balance * shdPrice).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : null;

  return (
    <div className="absolute top-16 right-4 z-50">
      <div className="bg-black/95 border-2 border-cyan-400 rounded-lg p-4 shadow-2xl min-w-[220px]"
        style={{ boxShadow: '0 0 20px rgba(0, 255, 255, 0.3)' }}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <img src={POUCH_LOGO} alt="Pouch" className="w-8 h-8 object-contain" />
            <span className="text-cyan-400 font-mono font-bold text-sm">SHD POUCH</span>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className={`text-3xl font-bold font-mono bloom-glow ${getBalanceColor(user?.shard_balance)}`}>
          {user?.shard_balance?.toLocaleString() || '0'}
        </div>
        <div className="text-xs text-gray-400 font-mono mt-1">SHD Balance</div>

        <div className="mt-3 border-t border-cyan-400/30 pt-3">
          <div className="text-xs text-gray-400 font-mono mb-1">SHD / USD Rate</div>
          {priceLoading && !shdPrice ? (
            <div className="text-yellow-400 font-mono text-xs animate-pulse">Fetching price...</div>
          ) : shdPrice ? (
            <>
              <div className="text-green-400 font-mono text-sm font-bold">
                1 SHD = ${shdPrice.toFixed(6)} USD
              </div>
              {usdValue && (
                <div className="text-cyan-300 font-mono text-xs mt-1">
                  ≈ ${usdValue} USD total
                </div>
              )}
            </>
          ) : (
            <div className="text-gray-500 font-mono text-xs">Price unavailable</div>
          )}
        </div>
      </div>
    </div>
  );
}

export { POUCH_LOGO };