import './App.css'
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import VisualEditAgent from '@/lib/VisualEditAgent'
import NavigationTracker from '@/lib/NavigationTracker'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ProtectedRoute from '@/components/ProtectedRoute';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import CapsuleOS from '@/pages/CapsuleOS';
import TRGTuner from '@/pages/TRGTuner';
import CarDiagnostics from '@/pages/CarDiagnostics';
import MailApp from '@/pages/MailApp';
import UserDirectory from '@/pages/UserDirectory';
import AmpPlayer from '@/pages/AmpPlayer';
import RubyBrowser from '@/pages/RubyBrowser';
import TurnOff from '@/pages/TurnOff';
import OAuthConsent from '@/pages/OAuthConsent';

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;

const LayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

const AuthenticatedApp = () => {
  return (
    <Routes>
      {/* Public auth routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />

      {/* MCP OAuth consent page (must be outside ProtectedRoute) */}
      <Route path="/oauth/consent" element={<OAuthConsent />} />

      {/* All app routes are protected */}
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route path="/" element={
          <LayoutWrapper currentPageName={mainPageKey}>
            <MainPage />
          </LayoutWrapper>
        } />
        {Object.entries(Pages).map(([path, Page]) => (
          <Route
            key={path}
            path={`/${path}`}
            element={
              <LayoutWrapper currentPageName={path}>
                <Page />
              </LayoutWrapper>
            }
          />
        ))}
      </Route>

        <Route path="/capsule-os" element={
          <LayoutWrapper currentPageName="CapsuleOS">
            <CapsuleOS />
          </LayoutWrapper>
        } />
        <Route path="/trg-tuner" element={
          <LayoutWrapper currentPageName="TRGTuner">
            <TRGTuner />
          </LayoutWrapper>
        } />
        <Route path="/car-diagnostics" element={
          <LayoutWrapper currentPageName="CarDiagnostics">
            <CarDiagnostics />
          </LayoutWrapper>
        } />
        <Route path="/mail" element={
          <LayoutWrapper currentPageName="MailApp">
            <MailApp />
          </LayoutWrapper>
        } />
        <Route path="/user-directory" element={
          <LayoutWrapper currentPageName="UserDirectory">
            <UserDirectory />
          </LayoutWrapper>
        } />
        <Route path="/amp-player" element={
          <LayoutWrapper currentPageName="AmpPlayer">
            <AmpPlayer />
          </LayoutWrapper>
        } />
        <Route path="/ruby-browser" element={
          <LayoutWrapper currentPageName="RubyBrowser">
            <RubyBrowser />
          </LayoutWrapper>
        } />
        <Route path="/turn-off" element={
          <LayoutWrapper currentPageName="TurnOff">
            <TurnOff />
          </LayoutWrapper>
        } />

      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <NavigationTracker />
          <AuthenticatedApp />
        </Router>
        <Toaster />
        <VisualEditAgent />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App