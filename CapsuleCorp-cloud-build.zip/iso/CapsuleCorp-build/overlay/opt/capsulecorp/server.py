from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import json
import os
import subprocess
import threading

ROOT = Path('/opt/capsulecorp/app')
SETUP_LOCK = threading.Lock()
setup_process = None


def nmcli(*args):
    result = subprocess.run(
        ['nmcli', '--wait', '5', *args], capture_output=True, text=True,
        timeout=8, check=True, env={**os.environ, 'LC_ALL': 'C'},
    )
    return result.stdout.strip()


def split_fields(line):
    fields, field, escaped = [], '', False
    for char in line:
        if escaped:
            field += char
            escaped = False
        elif char == '\\':
            escaped = True
        elif char == ':':
            fields.append(field)
            field = ''
        else:
            field += char
    fields.append(field)
    return fields


def network_status():
    state = nmcli('-t', '-f', 'STATE,CONNECTIVITY', 'general', 'status')
    values = split_fields(state)
    connectivity = values[1] if len(values) > 1 else 'unknown'
    devices = nmcli('-t', '-f', 'DEVICE,TYPE,STATE,CONNECTION', 'device', 'status')
    active = [split_fields(row) for row in devices.splitlines()]
    active = [row for row in active if len(row) == 4 and row[1] != 'loopback' and row[2].startswith('connected')]
    return {
        'online': True if connectivity == 'full' else False if connectivity in ('none', 'portal', 'limited') else None,
        'connected': bool(active),
        'connection': active[0][3] if active else '',
        'interface': active[0][0] if active else '',
        'connectivity': connectivity,
    }


def open_network_setup():
    global setup_process
    with SETUP_LOCK:
        if setup_process is not None and setup_process.poll() is None:
            return {'opened': True, 'already_open': True}
        # Inherits the active graphical user's DISPLAY/DBus session. No shell or
        # user-supplied command arguments. Wi-Fi passwords stay inside nmtui.
        setup_process = subprocess.Popen(
            ['xterm', '-T', 'Internet connectivity — close when finished',
             '-geometry', '95x30', '-e', 'nmtui'],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return {'opened': True, 'already_open': False}

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def valid_host(self):
        return self.headers.get('Host') == f'127.0.0.1:{self.server.server_port}'

    def json_response(self, code, value):
        data = json.dumps(value).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if not self.valid_host():
            return self.json_response(403, {'error': 'Invalid local host'})
        path = urlsplit(self.path).path
        if path == '/api/local/network/status':
            try:
                return self.json_response(200, network_status())
            except (OSError, subprocess.SubprocessError):
                return self.json_response(503, {'online': None, 'connected': False, 'connection': '', 'interface': '', 'error': 'NetworkManager status is unavailable'})
        if path.startswith('/api/'):
            return self.json_response(404, {'error': 'Unknown local endpoint'})
        if not Path(self.translate_path(path)).exists() and not Path(path).suffix:
            self.path = '/index.html'
        super().do_GET()

    def do_POST(self):
        expected_origin = f'http://127.0.0.1:{self.server.server_port}'
        if not self.valid_host() or self.headers.get('Origin') != expected_origin:
            return self.json_response(403, {'error': 'Local same-origin request required'})
        if urlsplit(self.path).path != '/api/local/network/setup':
            return self.json_response(404, {'error': 'Unknown local endpoint'})
        try:
            return self.json_response(200, open_network_setup())
        except OSError:
            return self.json_response(503, {'error': 'Could not open network setup'})


if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', 8080), Handler).serve_forever()
