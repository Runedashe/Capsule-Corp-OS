# Capsule Corp ISO build preparation

Status: build preparation only. No new ISO has been generated or boot-tested.

The app folder contains the supplied cyber-ruby-nexus-574e0e6f.zip source with local-hosting fixes and the requested login, internet setup, logo and USB diagnostics changes. The SDK receives its remote appBaseUrl, and MCP consent requests use the remote backend URL. Existing authentication checks remain. The builder configures app ID 6870dea75e7cf7b0574e0e6f and backend https://cyber-ruby-nexus-574e0e6f.base44.app. No API key is included.

## Requested additions

- The supplied Capsule Corp Logo.png is bundled unchanged. It appears on black during browser loading, on the login screen, and in the configured Plymouth Linux boot splash. The login is launched directly so network setup does not wait for cloud authentication.
- The login connectivity section reads NetworkManager status and opens the native nmtui Wi-Fi/Ethernet settings before app sign-in. Wi-Fi passwords are entered directly into nmtui. Unknown internet status is distinguished from confirmed connectivity. The native API listens on loopback only; setup requires the same browser origin and expected Host header.
- Car Diagnostics now uses Web Serial to communicate with a real ELM327-compatible USB serial adapter. It requires adapter identification and a valid vehicle response before reporting connection. Supported standard sensor reads cover RPM, speed, coolant and throttle. Readings are timestamped manual snapshots; unsupported or missing data is shown without substituting values.
- Select the baud rate specified by the adapter (9600, 38400 or 115200). The browser asks for port selection. USB serial device permissions are granted to the active local desktop session through udev. J2534/proprietary adapters need a different driver and are not supported here.
- Removed the original randomly generated diagnostics and simulated code clearing. Fault-code decoding and ECU writing are not implemented in the new driver. TRG Tuner saves an explicitly local plan and links to real diagnostics; it no longer reports fictional vehicle programming or effects.

Target: Debian 13 amd64 live USB/DVD, launching the bundled app in Chromium through a loopback-only Python server. This provides Linux underneath the web desktop; browser terminal controls do not become native OS commands automatically.

## Build

On this Windows computer, open the companion Build-CapsuleCorp.cmd in the outputs folder. It starts the existing CapsuleDebian distribution as root. It requires this bundle to remain at its current outputs path. The app dependency scripts run as the unprivileged nobody account in a temporary Linux directory.

Alternatively, on a Debian 13 amd64 builder with root or sudo, internet, and at least 15 GB free disk space, extract the bundle and run:

```sh
bash build.sh
```

The script installs build packages on that builder, builds the locked npm app, creates an isolated workspace under /var/tmp, runs Debian live-build, then writes CapsuleCorpOS-live-amd64.iso and its checksum to the parent directory. It does not install to or format a target disk. It retains the workspace and build log for diagnosis.

Build procedure reference: https://live-team.pages.debian.net/live-manual/html/live-manual/the-basics.en.html

## Remaining validation

- Verify the Base44 backend permits this localhost origin and app ID. Email login and OAuth redirects must be tested with an authorized account. An app ID is not an authentication credential.
- Test BIOS and UEFI boot in a VM, then on intended hardware. Secure Boot support has not been validated.
- Confirm Chromium starts, the login renders, network setup works, and desktop applications function after sign-in. Openbox provides an xterm via its right-click menu; use nmtui there for Wi-Fi setup if needed.
- Base44 entities, integrations, remotely hosted assets and sign-in remain online dependencies. The ZIP includes some backend function source and entity definitions, but this ISO builder does not deploy a local Base44 backend.
- Changes in a normal live session are lost at shutdown; persistent storage is not configured by this build.

Current environment blocker: WSL returns Wsl/Service/E_ACCESSDENIED. The earlier Capsule Corp ISO found elsewhere in the workspace contains different customizations and has not been substituted for this export.

Verification: the updated application compiled successfully using a Vite/Babel verification pipeline (2,719 modules), and the logo and connectivity section were inspected in the browser. The standard Linux build still uses Vite/esbuild with Base44 legacy imports enabled. Fifteen network-server software tests passed. OBD protocol tests passed for decoding, supported PIDs, handshake, serialization, no-data responses, rejected write commands, timeouts and disconnects. Those tests use protocol fixtures, not physical hardware; no test fixture is shipped in the application. Graphical startup waits for the loopback app server before opening Chromium.

Still unverified: physical USB/vehicle communication, native Linux network-settings window, Plymouth display, BIOS/UEFI boot, Base44 account login, and end-to-end ISO generation. No new .iso exists from this build yet.

Implementation references: https://developer.chrome.com/docs/capabilities/serial and https://www.elmelectronics.com/wp-content/uploads/2016/07/ELM327DS.pdf ; NetworkManager status semantics: https://manpages.debian.org/trixie/network-manager/nmcli.1.en.html
