#!/usr/bin/env bash
set -euo pipefail
# Run on a Debian amd64 builder with root or sudo access.
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec > >(tee "$HERE/build.log") 2>&1
trap 'result=$?; if ((result != 0)); then echo "BUILD FAILED (exit $result). See $HERE/build.log"; fi' EXIT
if [[ $(uname -m) != x86_64 ]]; then echo 'An amd64 Linux builder is required.' >&2; exit 1; fi
SUDO=()
export DEBIAN_FRONTEND=noninteractive
if [[ $EUID != 0 ]]; then SUDO=(sudo); fi
"${SUDO[@]}" apt-get update
"${SUDO[@]}" apt-get install -y ca-certificates live-build debootstrap squashfs-tools xorriso isolinux syslinux-common grub-pc-bin grub-efi-amd64-bin mtools dosfstools nodejs npm
APP_WORK=$(mktemp -d /var/tmp/capsule-app.XXXXXXXX)
cp -a "$HERE/app/." "$APP_WORK/"
APP_RUN=()
if [[ $EUID == 0 ]]; then
  chown -R nobody:nogroup "$APP_WORK"
  APP_RUN=(runuser -u nobody --)
fi
cd "$APP_WORK"
"${APP_RUN[@]}" env npm_config_cache="$APP_WORK/.npm-cache" npm ci --no-audit --no-fund
"${APP_RUN[@]}" env BASE44_LEGACY_SDK_IMPORTS=true VITE_BASE44_APP_ID=6870dea75e7cf7b0574e0e6f VITE_BASE44_BACKEND_URL=https://cyber-ruby-nexus-574e0e6f.base44.app npm run build
test -s dist/index.html
BUILD=$(mktemp -d /var/tmp/capsule-build.XXXXXXXX)
echo "Build workspace: $BUILD"
cd "$BUILD"
lb config --distribution trixie --architecture amd64 --binary-image iso-hybrid --bootloaders 'syslinux grub-efi' --cache false --archive-areas 'main contrib non-free-firmware' --debian-installer none --bootappend-live 'boot=live components username=user hostname=capsulecorp quiet splash' --iso-volume CAPSULE_CORP
mkdir -p config/package-lists
cat > config/package-lists/capsule.list.chroot <<'PACKAGES'
linux-image-amd64
live-boot
live-config
systemd-sysv
xorg
openbox
lightdm
chromium
python3
network-manager
network-manager-gnome
network-manager-config-connectivity-debian
polkitd
plymouth
plymouth-themes
feh
dbus-x11
xterm
ca-certificates
fonts-dejavu
fonts-noto-color-emoji
firmware-linux
firmware-iwlwifi
firmware-realtek
PACKAGES
mkdir -p config/includes.chroot
cp -a "$HERE/overlay/." config/includes.chroot/
mkdir -p config/hooks/normal
cp "$HERE/hooks/0500-capsule.hook.chroot" config/hooks/normal/
chmod +x config/hooks/normal/0500-capsule.hook.chroot
mkdir -p config/includes.chroot/opt/capsulecorp/app
cp -a "$APP_WORK/dist/." config/includes.chroot/opt/capsulecorp/app/
chmod +x config/includes.chroot/usr/local/bin/capsule-session
"${SUDO[@]}" lb build
"${SUDO[@]}" chown "$(id -u):$(id -g)" live-image-amd64.hybrid.iso
cp live-image-amd64.hybrid.iso "$HERE/../CapsuleCorpOS-live-amd64.iso"
cd "$HERE/.."
sha256sum CapsuleCorpOS-live-amd64.iso > CapsuleCorpOS-live-amd64.sha256
xorriso -indev CapsuleCorpOS-live-amd64.iso -report_el_torito plain > CapsuleCorpOS-boot-report.txt 2>&1
echo 'ISO created. BIOS/UEFI VM boot tests and authenticated app tests are still required.'
